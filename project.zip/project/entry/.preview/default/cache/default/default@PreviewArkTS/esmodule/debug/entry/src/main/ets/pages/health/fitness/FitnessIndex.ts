if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FitnessIndex_Params {
    fitnessRecords?: FitnessRecord[];
}
import type { FitnessRecord } from './FitnessRecord';
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { HealthDatabase } from "@normalized:N&&&entry/src/main/ets/HealthDatabase/HealthDatabase&";
import type common from "@ohos:app.ability.common";
export class FitnessIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__fitnessRecords = new ObservedPropertyObjectPU([], this, "fitnessRecords");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FitnessIndex_Params) {
        if (params.fitnessRecords !== undefined) {
            this.fitnessRecords = params.fitnessRecords;
        }
    }
    updateStateVars(params: FitnessIndex_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__fitnessRecords.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__fitnessRecords.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __fitnessRecords: ObservedPropertyObjectPU<FitnessRecord[]>;
    get fitnessRecords() {
        return this.__fitnessRecords.get();
    }
    set fitnessRecords(newValue: FitnessRecord[]) {
        this.__fitnessRecords.set(newValue);
    }
    onPageShow() {
        this.loadRecords();
    }
    async loadRecords() {
        try {
            const context = getContext(this) as common.Context;
            const db = HealthDatabase.getInstance(context);
            this.fitnessRecords = await db.getAllFitnessRecords();
            console.log('Records loaded:', this.fitnessRecords.length);
        }
        catch (err) {
            console.error('Failed to load records:', err);
            promptAction.showToast({ message: 'Failed to load records' });
        }
    }
    async deleteRecord(id: string) {
        try {
            const context = getContext(this) as common.Context;
            const db = HealthDatabase.getInstance(context);
            const success = await db.deleteFitnessRecord(id);
            if (success) {
                this.fitnessRecords = this.fitnessRecords.filter(r => r.id !== id);
                promptAction.showToast({ message: 'Deleted successfully' });
            }
            else {
                promptAction.showToast({ message: 'Failed to delete' });
            }
        }
        catch (err) {
            console.error('Error deleting record:', err);
            promptAction.showToast({ message: 'Error deleting' });
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(47:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(48:7)", "entry");
            Row.width('100%');
            Row.padding(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Fitness Records');
            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(49:9)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(53:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('Add Record');
            Button.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(55:9)", "entry");
            Button.type(ButtonType.Circle);
            Button.onClick(() => {
                router.push({ url: 'pages/health/fitness/FitnessAddEdit', params: { mode: 'add' } });
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.fitnessRecords.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(65:9)", "entry");
                        Column.width('100%');
                        Column.height('70%');
                        Column.justifyContent(FlexAlign.Center);
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('No records found');
                        Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(66:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor('#999999');
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 10 });
                        List.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(75:9)", "entry");
                        List.width('100%');
                        List.height('80%');
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    itemCreation2(elmtId, isInitialRender);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(77:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(78:15)", "entry");
                                        Column.width('100%');
                                        Column.padding(10);
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(79:17)", "entry");
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.date);
                                        Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(80:19)", "entry");
                                        Text.fontSize(18);
                                        Text.fontWeight(FontWeight.Bold);
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Blank.create();
                                        Blank.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(84:19)", "entry");
                                    }, Blank);
                                    Blank.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(`${item.calories} kcal`);
                                        Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(86:19)", "entry");
                                        Text.fontSize(16);
                                    }, Text);
                                    Text.pop();
                                    Row.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(90:17)", "entry");
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(`Exercise: ${item.duration} mins`);
                                        Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(91:19)", "entry");
                                        Text.fontSize(14);
                                        Text.fontColor('#666666');
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Blank.create();
                                        Blank.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(95:19)", "entry");
                                    }, Blank);
                                    Blank.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(`Stand: ${item.standTime} hrs`);
                                        Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(97:19)", "entry");
                                        Text.fontSize(14);
                                        Text.fontColor('#666666');
                                    }, Text);
                                    Text.pop();
                                    Row.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(102:17)", "entry");
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Blank.create();
                                        Blank.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(103:19)", "entry");
                                    }, Blank);
                                    Blank.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(105:19)", "entry");
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Button.createWithLabel('Edit');
                                        Button.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(106:21)", "entry");
                                        Button.type(ButtonType.Normal);
                                        Button.height(30);
                                        Button.fontSize(12);
                                        Button.onClick(() => {
                                            router.push({
                                                url: 'pages/health/fitness/FitnessAddEdit',
                                                params: {
                                                    mode: 'edit',
                                                    record: JSON.stringify(item)
                                                }
                                            });
                                        });
                                    }, Button);
                                    Button.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Button.createWithLabel('Delete');
                                        Button.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(120:21)", "entry");
                                        Button.type(ButtonType.Normal);
                                        Button.height(30);
                                        Button.fontSize(12);
                                        Button.margin({ left: 10 });
                                        Button.backgroundColor('#FF0000');
                                        Button.onClick(() => this.deleteRecord(item.id));
                                    }, Button);
                                    Button.pop();
                                    Row.pop();
                                    Row.pop();
                                    Column.pop();
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.fitnessRecords, forEachItemGenFunction);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "FitnessIndex";
    }
}
registerNamedRoute(() => new FitnessIndex(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/health/fitness/FitnessIndex", pageFullPath: "entry/src/main/ets/pages/health/fitness/FitnessIndex", integratedHsp: "false", moduleType: "followWithHap" });
