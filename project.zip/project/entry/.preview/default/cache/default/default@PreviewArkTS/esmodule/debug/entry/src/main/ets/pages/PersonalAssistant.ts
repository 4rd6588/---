if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PersonalAssistant_Params {
}
import router from "@ohos:router";
class PersonalAssistant extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PersonalAssistant_Params) {
    }
    updateStateVars(params: PersonalAssistant_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 使用Column作为根容器实现纵向布局
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(9:5)", "entry");
            // 使用Column作为根容器实现纵向布局
            Column.width('100%');
            // 使用Column作为根容器实现纵向布局
            Column.height('100%');
            // 使用Column作为根容器实现纵向布局
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 应用标题
            Text.create('Open Duola');
            Text.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(11:7)", "entry");
            // 应用标题
            Text.fontSize(30);
            // 应用标题
            Text.fontWeight(FontWeight.Bold);
            // 应用标题
            Text.margin({ top: 10, bottom: 20 });
            // 应用标题
            Text.width('100%');
            // 应用标题
            Text.textAlign(TextAlign.Center);
        }, Text);
        // 应用标题
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 学习板块 - 占1/3高度
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(19:7)", "entry");
            // 学习板块 - 占1/3高度
            Column.width('100%');
            // 学习板块 - 占1/3高度
            Column.height('30%');
            // 学习板块 - 占1/3高度
            Column.padding(15);
            // 学习板块 - 占1/3高度
            Column.border({ width: 1, color: '#A5D6A7' });
            // 学习板块 - 占1/3高度
            Column.borderRadius(10);
            // 学习板块 - 占1/3高度
            Column.margin({ bottom: 15 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Study');
            Text.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(20:9)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            Text.backgroundColor('#A5D6A7');
            Text.width('100%');
            Text.padding(20);
            Text.textAlign(TextAlign.Center);
            Text.borderRadius(10);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('You can record your learning record here');
            Text.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(29:9)", "entry");
            Text.fontSize(18);
            Text.margin({ top: 20, bottom: 10 });
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Final Exam、Review Notes、Reading Notes、Electronic Books');
            Text.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(34:9)", "entry");
            Text.fontSize(16);
            Text.opacity(0.7);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        // 学习板块 - 占1/3高度
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 生活板块 - 占1/3高度
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(47:7)", "entry");
            // 生活板块 - 占1/3高度
            Column.width('100%');
            // 生活板块 - 占1/3高度
            Column.height('30%');
            // 生活板块 - 占1/3高度
            Column.padding(15);
            // 生活板块 - 占1/3高度
            Column.border({ width: 1, color: '#90CAF9' });
            // 生活板块 - 占1/3高度
            Column.borderRadius(10);
            // 生活板块 - 占1/3高度
            Column.margin({ bottom: 15 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Life');
            Text.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(48:9)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            Text.backgroundColor('#90CAF9');
            Text.width('100%');
            Text.padding(20);
            Text.textAlign(TextAlign.Center);
            Text.borderRadius(10);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('You can record your life here');
            Text.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(57:9)", "entry");
            Text.fontSize(18);
            Text.margin({ top: 20, bottom: 10 });
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Clothes Waiting To Be Washed、Important Meetings、Dateing、Birthday Gathering');
            Text.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(62:9)", "entry");
            Text.fontSize(16);
            Text.opacity(0.7);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        // 生活板块 - 占1/3高度
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 健康板块 - 占1/3高度
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(75:7)", "entry");
            // 健康板块 - 占1/3高度
            Column.width('100%');
            // 健康板块 - 占1/3高度
            Column.height('30%');
            // 健康板块 - 占1/3高度
            Column.padding(15);
            // 健康板块 - 占1/3高度
            Column.border({ width: 1, color: '#FFAB91' });
            // 健康板块 - 占1/3高度
            Column.borderRadius(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Health');
            Text.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(76:9)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            Text.backgroundColor('#FFAB91');
            Text.width('100%');
            Text.padding(20);
            Text.textAlign(TextAlign.Center);
            Text.borderRadius(10);
            Text.onClick(() => {
                setTimeout(() => {
                    router.pushUrl({
                        url: 'pages/HealthIndex',
                    }, router.RouterMode.Standard);
                }, 500);
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('You can record your health here');
            Text.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(91:9)", "entry");
            Text.fontSize(18);
            Text.margin({ top: 20, bottom: 10 });
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Sleep Time、Fitness Record、Psychological State');
            Text.debugLine("entry/src/main/ets/pages/PersonalAssistant.ets(96:9)", "entry");
            Text.fontSize(16);
            Text.opacity(0.7);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        // 健康板块 - 占1/3高度
        Column.pop();
        // 使用Column作为根容器实现纵向布局
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "PersonalAssistant";
    }
}
registerNamedRoute(() => new PersonalAssistant(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/PersonalAssistant", pageFullPath: "entry/src/main/ets/pages/PersonalAssistant", integratedHsp: "false", moduleType: "followWithHap" });
