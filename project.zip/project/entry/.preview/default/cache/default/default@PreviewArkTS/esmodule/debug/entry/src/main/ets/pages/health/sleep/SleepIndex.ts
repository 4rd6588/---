if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SleepIndex_Params {
    sleepRecords?: SleepRecord[];
    isRefreshing?: boolean;
}
import type { SleepRecord } from './SleepRecord';
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
export class SleepIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__sleepRecords = new ObservedPropertyObjectPU([], this, "sleepRecords");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SleepIndex_Params) {
        if (params.sleepRecords !== undefined) {
            this.sleepRecords = params.sleepRecords;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
    }
    updateStateVars(params: SleepIndex_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__sleepRecords.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__sleepRecords.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __sleepRecords: ObservedPropertyObjectPU<SleepRecord[]>;
    get sleepRecords() {
        return this.__sleepRecords.get();
    }
    set sleepRecords(newValue: SleepRecord[]) {
        this.__sleepRecords.set(newValue);
    }
    private __isRefreshing: ObservedPropertySimplePU<boolean>;
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue: boolean) {
        this.__isRefreshing.set(newValue);
    }
    aboutToAppear() {
        this.loadSleepRecords();
    }
    loadSleepRecords() {
        // 模拟从数据库加载数据
        this.sleepRecords = [
            { id: '1', date: '2023-05-01', sleepHours: 7.5, quality: '良好' },
            { id: '2', date: '2023-05-02', sleepHours: 6, quality: '一般' },
            { id: '3', date: '2023-05-03', sleepHours: 8, quality: '优秀' }
        ];
        this.isRefreshing = false;
    }
    deleteRecord(id: string) {
        promptAction.showDialog({
            title: { "id": 16777239, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
            message: { "id": 16777238, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
            buttons: [
                { text: { "id": 16777237, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, color: '#999999' },
                { text: { "id": 16777239, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, color: '#FF0000' }
            ]
        }).then(result => {
            if (result.index === 1) {
                // 模拟删除操作
                this.sleepRecords = this.sleepRecords.filter(record => record.id !== id);
            }
        });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(42:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(43:7)", "entry");
            Row.width('100%');
            Row.padding(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777255, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(44:9)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(48:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777235, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(50:9)", "entry");
            Button.type(ButtonType.Circle);
            Button.onClick(() => {
                router.push({ url: 'pages/health/sleep/SleepAddEdit', params: { mode: 'add' } });
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 10 });
            List.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(59:7)", "entry");
            List.layoutWeight(1);
            List.divider({ strokeWidth: 1, color: '#F1F1F1' });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(61:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create();
                            Column.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(62:13)", "entry");
                            Column.width('100%');
                            Column.padding(10);
                            Column.borderRadius(10);
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(63:15)", "entry");
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.date);
                            Text.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(64:17)", "entry");
                            Text.fontSize(18);
                            Text.fontWeight(FontWeight.Bold);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Blank.create();
                            Blank.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(68:17)", "entry");
                        }, Blank);
                        Blank.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(`${item.sleepHours}小时`);
                            Text.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(70:17)", "entry");
                            Text.fontSize(16);
                        }, Text);
                        Text.pop();
                        Row.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(74:15)", "entry");
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create({ "id": 16777254, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" } + `: ${item.quality}`);
                            Text.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(75:17)", "entry");
                            Text.fontSize(14);
                            Text.fontColor('#666666');
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Blank.create();
                            Blank.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(79:17)", "entry");
                        }, Blank);
                        Blank.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(81:17)", "entry");
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel({ "id": 16777240, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                            Button.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(82:19)", "entry");
                            Button.type(ButtonType.Normal);
                            Button.height(30);
                            Button.fontSize(12);
                            Button.onClick(() => {
                                router.push({
                                    url: 'pages/health/sleep/SleepAddEdit',
                                    params: {
                                        mode: 'edit',
                                        record: JSON.stringify(item)
                                    }
                                });
                            });
                        }, Button);
                        Button.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel({ "id": 16777239, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                            Button.debugLine("entry/src/main/ets/pages/health/sleep/SleepIndex.ets(96:19)", "entry");
                            Button.type(ButtonType.Normal);
                            Button.height(30);
                            Button.fontSize(12);
                            Button.margin({ left: 10 });
                            Button.backgroundColor('#FF0000');
                            Button.onClick(() => this.deleteRecord(item.id));
                        }, Button);
                        Button.pop();
                        Row.pop();
                        Row.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.sleepRecords, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "SleepIndex";
    }
}
registerNamedRoute(() => new SleepIndex(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/health/sleep/SleepIndex", pageFullPath: "entry/src/main/ets/pages/health/sleep/SleepIndex", integratedHsp: "false", moduleType: "followWithHap" });
