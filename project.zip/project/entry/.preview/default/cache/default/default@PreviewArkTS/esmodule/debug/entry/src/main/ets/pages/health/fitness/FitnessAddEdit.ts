if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FitnessAddEdit_Params {
    mode?: 'add' | 'edit';
    record?: FitnessRecord;
    datePickerVisible?: boolean;
}
import type { FitnessRecord } from './FitnessRecord';
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { HealthDatabase } from "@normalized:N&&&entry/src/main/ets/HealthDatabase/HealthDatabase&";
import type common from "@ohos:app.ability.common";
interface DatePickerValue {
    year: number;
    month: number;
    day: number;
}
interface RouteParams {
    mode?: 'add' | 'edit';
    record?: string;
}
export class FitnessAddEdit extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.mode = 'add';
        this.__record = new ObservedPropertyObjectPU({
            id: '',
            date: '',
            calories: 0,
            duration: 0,
            standTime: 0
        }, this, "record");
        this.__datePickerVisible = new ObservedPropertySimplePU(false, this, "datePickerVisible");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FitnessAddEdit_Params) {
        if (params.mode !== undefined) {
            this.mode = params.mode;
        }
        if (params.record !== undefined) {
            this.record = params.record;
        }
        if (params.datePickerVisible !== undefined) {
            this.datePickerVisible = params.datePickerVisible;
        }
    }
    updateStateVars(params: FitnessAddEdit_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__record.purgeDependencyOnElmtId(rmElmtId);
        this.__datePickerVisible.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__record.aboutToBeDeleted();
        this.__datePickerVisible.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private mode: 'add' | 'edit';
    private __record: ObservedPropertyObjectPU<FitnessRecord>;
    get record() {
        return this.__record.get();
    }
    set record(newValue: FitnessRecord) {
        this.__record.set(newValue);
    }
    private __datePickerVisible: ObservedPropertySimplePU<boolean>;
    get datePickerVisible() {
        return this.__datePickerVisible.get();
    }
    set datePickerVisible(newValue: boolean) {
        this.__datePickerVisible.set(newValue);
    }
    aboutToAppear() {
        const params: RouteParams = router.getParams() as RouteParams;
        if (params?.mode) {
            this.mode = params.mode;
            if (this.mode === 'edit' && params.record) {
                this.record = JSON.parse(params.record) as FitnessRecord;
            }
            else {
                const now = new Date();
                this.record.date = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')}`;
                this.record.id = Date.now().toString();
            }
        }
    }
    async saveRecord() {
        if (!this.validateRecord()) {
            promptAction.showToast({ message: '请填写有效数据' });
            return;
        }
        try {
            const context = getContext(this) as common.Context;
            const db = HealthDatabase.getInstance(context);
            const success = this.mode === 'add'
                ? await db.addFitnessRecord(this.record)
                : await db.updateFitnessRecord(this.record);
            if (success) {
                promptAction.showToast({ message: '保存成功' });
                router.back();
            }
            else {
                promptAction.showToast({ message: '保存失败，请重试' });
            }
        }
        catch (err) {
            console.error('保存记录时出错:', err);
            promptAction.showToast({ message: '保存出错，请重试' });
        }
    }
    private validateRecord(): boolean {
        return !!this.record.date &&
            this.record.calories > 0 &&
            this.record.duration > 0 &&
            this.record.standTime >= 0;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(80:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
            Column.justifyContent(FlexAlign.Start);
            Column.backgroundColor('#fff5e7');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(81:7)", "entry");
            Row.width('80%');
            Row.height(80);
            Row.backgroundColor('#c8e3f6');
            Row.borderRadius(16);
            Row.border({
                width: 2,
                color: '#c8e3f6' // 边框颜色与主题一致
            });
            Row.justifyContent(FlexAlign.Center);
            Row.alignItems(VerticalAlign.Center);
            Row.margin({ bottom: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.mode === 'add' ? '添加健身记录' : '编辑健身记录');
            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(82:9)", "entry");
            Text.fontSize(30);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#fff5e7');
            Text.margin({ left: 16 });
        }, Text);
        Text.pop();
        Row.pop();
        // 日期选择部分
        this.buildDatePicker.bind(this)();
        this.buildCaloriesInput.bind(this)();
        this.buildDurationInput.bind(this)();
        this.buildStandTimeInput.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('保存');
            Button.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(109:7)", "entry");
            Button.width('80%');
            Button.height(50);
            Button.margin({ top: 20 });
            Button.onClick(() => this.saveRecord());
            Button.backgroundColor('#c8e3f6');
            Button.fontColor(Color.White);
        }, Button);
        Button.pop();
        Column.pop();
    }
    buildDatePicker(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(127:5)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('日期');
            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(128:7)", "entry");
            Text.fontSize(16);
            Text.fontColor('#9ac5e6');
            Text.width('30%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.record.date);
            Button.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(133:7)", "entry");
            Button.width('70%');
            Button.onClick(() => this.datePickerVisible = true);
            Button.borderRadius(4);
            Button.borderWidth(1);
            Button.backgroundColor('#c8e3f6');
            Button.borderColor('#CCCCCC');
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.datePickerVisible) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        DatePicker.create({
                            start: new Date('2000-01-01'),
                            end: new Date('2100-12-31'),
                            selected: new Date(this.record.date)
                        });
                        DatePicker.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(147:7)", "entry");
                        DatePicker.onChange((value: DatePickerValue) => {
                            this.record.date = `${value.year}-${value.month.toString().padStart(2, '0')}-${value.day.toString().padStart(2, '0')}`;
                            this.datePickerVisible = false;
                        });
                    }, DatePicker);
                    DatePicker.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
    }
    buildCaloriesInput(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(161:5)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('卡路里(千卡)');
            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(162:7)", "entry");
            Text.fontSize(16);
            Text.fontColor('#9ac5e6');
            Text.width('30%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ text: this.record.calories.toString() });
            TextInput.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(167:7)", "entry");
            TextInput.type(InputType.Number);
            TextInput.width('70%');
            TextInput.height(40);
            TextInput.borderRadius(4);
            TextInput.borderWidth(1);
            TextInput.borderColor('#CCCCCC');
            TextInput.onChange((value: string) => {
                this.record.calories = parseFloat(value) || 0;
            });
        }, TextInput);
        Row.pop();
    }
    buildDurationInput(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(184:5)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('锻炼(分钟)');
            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(185:7)", "entry");
            Text.fontSize(16);
            Text.fontColor('#9ac5e6');
            Text.width('30%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ text: this.record.duration.toString() });
            TextInput.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(190:7)", "entry");
            TextInput.type(InputType.Number);
            TextInput.width('70%');
            TextInput.height(40);
            TextInput.borderRadius(4);
            TextInput.borderWidth(1);
            TextInput.borderColor('#CCCCCC');
            TextInput.onChange((value: string) => {
                this.record.duration = parseFloat(value) || 0;
            });
        }, TextInput);
        Row.pop();
    }
    buildStandTimeInput(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(207:5)", "entry");
            Row.width('100%');
            Row.margin({ bottom: 15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('站立(小时)');
            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(208:7)", "entry");
            Text.fontSize(16);
            Text.fontColor('#9ac5e6');
            Text.width('30%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ text: this.record.standTime.toString() });
            TextInput.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(213:7)", "entry");
            TextInput.type(InputType.Number);
            TextInput.width('70%');
            TextInput.height(40);
            TextInput.borderRadius(4);
            TextInput.borderWidth(1);
            TextInput.borderColor('#CCCCCC');
            TextInput.onChange((value: string) => {
                this.record.standTime = parseFloat(value) || 0;
            });
        }, TextInput);
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "FitnessAddEdit";
    }
}
registerNamedRoute(() => new FitnessAddEdit(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/health/fitness/FitnessAddEdit", pageFullPath: "entry/src/main/ets/pages/health/fitness/FitnessAddEdit", integratedHsp: "false", moduleType: "followWithHap" });
