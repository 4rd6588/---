if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SleepAddEdit_Params {
    mode?: 'add' | 'edit';
    record?: SleepRecord;
    datePickerVisible?: boolean;
}
import type { SleepRecord } from './SleepRecord';
import router from "@ohos:router";
interface GeneratedTypeLiteralInterface_2 {
    year: number;
    month: number;
    day: number;
}
interface GeneratedTypeLiteralInterface_1 {
    mode?: 'add' | 'edit';
    record?: string;
}
export class SleepAddEdit extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.mode = 'add';
        this.__record = new ObservedPropertyObjectPU({ id: '', date: '', sleepHours: 0, quality: '一般' }, this, "record");
        this.__datePickerVisible = new ObservedPropertySimplePU(false, this, "datePickerVisible");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SleepAddEdit_Params) {
        if (params.mode !== undefined) {
            this.mode = params.mode;
        }
        if (params.record !== undefined) {
            this.record = params.record;
        }
        if (params.datePickerVisible !== undefined) {
            this.datePickerVisible = params.datePickerVisible;
        }
    }
    updateStateVars(params: SleepAddEdit_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__record.purgeDependencyOnElmtId(rmElmtId);
        this.__datePickerVisible.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__record.aboutToBeDeleted();
        this.__datePickerVisible.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private mode: 'add' | 'edit';
    private __record: ObservedPropertyObjectPU<SleepRecord>;
    get record() {
        return this.__record.get();
    }
    set record(newValue: SleepRecord) {
        this.__record.set(newValue);
    }
    private __datePickerVisible: ObservedPropertySimplePU<boolean>;
    get datePickerVisible() {
        return this.__datePickerVisible.get();
    }
    set datePickerVisible(newValue: boolean) {
        this.__datePickerVisible.set(newValue);
    }
    aboutToAppear() {
        const params = router.getParams() as GeneratedTypeLiteralInterface_1;
        if (params?.mode) {
            this.mode = params.mode;
            if (this.mode === 'edit' && params.record) {
                try {
                    this.record = JSON.parse(params.record) as SleepRecord;
                }
                catch (e) {
                    console.error('Failed to parse record:', e);
                }
            }
            else {
                // 设置默认日期为当前日期
                const now = new Date();
                this.record.date = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')}`;
            }
        }
    }
    saveRecord() {
        // 这里应该是保存到数据库的逻辑
        console.log('保存记录:', this.record);
        router.back();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(48:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.mode === 'add' ? { "id": 16777235, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" } : { "id": 16777240, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(49:7)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ bottom: 20 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 日期选择部分
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(55:7)", "entry");
            // 日期选择部分
            Row.width('100%');
            // 日期选择部分
            Row.margin({ bottom: 15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777253, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(56:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.record.date);
            Button.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(59:9)", "entry");
            Button.type(ButtonType.Normal);
            Button.margin({ left: 10 });
            Button.onClick(() => {
                this.datePickerVisible = true;
            });
        }, Button);
        Button.pop();
        // 日期选择部分
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.datePickerVisible) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        DatePicker.create({
                            start: new Date('1970-01-01'),
                            end: new Date('2100-12-31'),
                            selected: new Date(this.record.date)
                        });
                        DatePicker.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(70:9)", "entry");
                        DatePicker.onChange((value: GeneratedTypeLiteralInterface_2) => {
                            this.record.date = `${value.year}-${value.month.toString().padStart(2, '0')}-${value.day.toString().padStart(2, '0')}`;
                            this.datePickerVisible = false;
                        });
                    }, DatePicker);
                    DatePicker.pop();
                });
            }
            // 睡眠时间输入
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 睡眠时间输入
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(82:7)", "entry");
            // 睡眠时间输入
            Row.width('100%');
            // 睡眠时间输入
            Row.margin({ bottom: 15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777256, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(83:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入睡眠小时数', text: this.record.sleepHours.toString() });
            TextInput.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(86:9)", "entry");
            TextInput.type(InputType.Number);
            TextInput.width('50%');
            TextInput.height(40);
            TextInput.margin({ left: 10 });
            TextInput.onChange((value: string) => {
                this.record.sleepHours = parseFloat(value) || 0;
            });
        }, TextInput);
        // 睡眠时间输入
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 睡眠质量选择
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(99:7)", "entry");
            // 睡眠质量选择
            Column.width('100%');
            // 睡眠质量选择
            Column.margin({ bottom: 30 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777254, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(100:9)", "entry");
            Text.fontSize(16);
            Text.margin({ bottom: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(104:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Radio.create({ value: '优秀', group: 'quality' });
            Radio.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(105:11)", "entry");
            Radio.checked(this.record.quality === '优秀');
            Radio.onChange((checked: boolean) => {
                if (checked)
                    this.record.quality = '优秀';
            });
        }, Radio);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('优秀');
            Text.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(110:11)", "entry");
            Text.margin({ left: 5, right: 15 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Radio.create({ value: '良好', group: 'quality' });
            Radio.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(113:11)", "entry");
            Radio.checked(this.record.quality === '良好');
            Radio.onChange((checked: boolean) => {
                if (checked)
                    this.record.quality = '良好';
            });
        }, Radio);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('良好');
            Text.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(118:11)", "entry");
            Text.margin({ left: 5, right: 15 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Radio.create({ value: '一般', group: 'quality' });
            Radio.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(121:11)", "entry");
            Radio.checked(this.record.quality === '一般');
            Radio.onChange((checked: boolean) => {
                if (checked)
                    this.record.quality = '一般';
            });
        }, Radio);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('一般');
            Text.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(126:11)", "entry");
            Text.margin({ left: 5 });
        }, Text);
        Text.pop();
        Row.pop();
        // 睡眠质量选择
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777252, "type": 10003, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/pages/health/sleep/SleepAddEdit.ets(133:7)", "entry");
            Button.width('80%');
            Button.height(50);
            Button.fontSize(18);
            Button.onClick(() => this.saveRecord());
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "SleepAddEdit";
    }
}
registerNamedRoute(() => new SleepAddEdit(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/health/sleep/SleepAddEdit", pageFullPath: "entry/src/main/ets/pages/health/sleep/SleepAddEdit", integratedHsp: "false", moduleType: "followWithHap" });
