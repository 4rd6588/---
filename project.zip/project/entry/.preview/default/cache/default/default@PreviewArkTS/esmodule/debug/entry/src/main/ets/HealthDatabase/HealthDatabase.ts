import relationalStore from "@ohos:data.relationalStore";
import type { FitnessRecord } from '../pages/health/fitness/FitnessRecord';
import type common from "@ohos:app.ability.common";
export class HealthDatabase {
    private static instance: HealthDatabase;
    private rdbStore: relationalStore.RdbStore | null = null;
    private context: common.Context | null = null;
    private constructor(context: common.Context) {
        this.context = context;
    }
    public static getInstance(context: common.Context): HealthDatabase {
        if (!HealthDatabase.instance) {
            HealthDatabase.instance = new HealthDatabase(context);
            HealthDatabase.instance.initDB();
        }
        return HealthDatabase.instance;
    }
    private async initDB(): Promise<void> {
        try {
            const STORE_CONFIG: relationalStore.StoreConfig = {
                name: 'HealthNotepad.db',
                securityLevel: relationalStore.SecurityLevel.S1
            };
            this.rdbStore = await relationalStore.getRdbStore(this.context!, STORE_CONFIG);
            await this.rdbStore.executeSql(`
        CREATE TABLE IF NOT EXISTS fitness_records (
          id TEXT PRIMARY KEY,
          date TEXT NOT NULL,
          calories REAL NOT NULL,
          duration REAL NOT NULL,
          standTime REAL NOT NULL
        )`);
            console.log('Database initialized successfully');
        }
        catch (err) {
            console.error('Failed to initialize database:', err);
        }
    }
    async addFitnessRecord(record: FitnessRecord): Promise<boolean> {
        if (!this.rdbStore) {
            console.error('Database not initialized');
            return false;
        }
        try {
            const valueBucket: relationalStore.ValuesBucket = {
                'id': record.id,
                'date': record.date,
                'calories': record.calories,
                'duration': record.duration,
                'standTime': record.standTime
            };
            await this.rdbStore.insert('fitness_records', valueBucket);
            console.log('Record added successfully:', record);
            return true;
        }
        catch (err) {
            console.error('Failed to add record:', err);
            return false;
        }
    }
    async updateFitnessRecord(record: FitnessRecord): Promise<boolean> {
        if (!this.rdbStore)
            return false;
        try {
            const valueBucket: relationalStore.ValuesBucket = {
                'date': record.date,
                'calories': record.calories,
                'duration': record.duration,
                'standTime': record.standTime
            };
            const predicates = new relationalStore.RdbPredicates('fitness_records');
            predicates.equalTo('id', record.id);
            await this.rdbStore.update(valueBucket, predicates);
            return true;
        }
        catch (err) {
            console.error('Failed to update record:', err);
            return false;
        }
    }
    async deleteFitnessRecord(id: string): Promise<boolean> {
        if (!this.rdbStore)
            return false;
        try {
            const predicates = new relationalStore.RdbPredicates('fitness_records');
            predicates.equalTo('id', id);
            await this.rdbStore.delete(predicates);
            return true;
        }
        catch (err) {
            console.error('Failed to delete record:', err);
            return false;
        }
    }
    async getAllFitnessRecords(): Promise<FitnessRecord[]> {
        if (!this.rdbStore) {
            console.error('Database not initialized');
            return [];
        }
        try {
            const predicates = new relationalStore.RdbPredicates('fitness_records');
            const columns = ['id', 'date', 'calories', 'duration', 'standTime'];
            const resultSet = await this.rdbStore.query(predicates, columns);
            const records: FitnessRecord[] = [];
            while (resultSet.goToNextRow()) {
                records.push({
                    id: resultSet.getString(resultSet.getColumnIndex('id')) || '',
                    date: resultSet.getString(resultSet.getColumnIndex('date')) || '',
                    calories: resultSet.getDouble(resultSet.getColumnIndex('calories')),
                    duration: resultSet.getDouble(resultSet.getColumnIndex('duration')),
                    standTime: resultSet.getDouble(resultSet.getColumnIndex('standTime'))
                });
            }
            resultSet.close();
            // 按日期降序排序
            return records.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        }
        catch (err) {
            console.error('Failed to get records:', err);
            return [];
        }
    }
}
