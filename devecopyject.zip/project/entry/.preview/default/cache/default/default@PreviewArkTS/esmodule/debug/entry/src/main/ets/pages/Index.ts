if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LoginPage_Params {
    username?: string;
    password?: string;
    message?: string;
}
class LoginPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__message = new ObservedPropertySimplePU('旅行loop', this, "message");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LoginPage_Params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params: LoginPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__username.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(9:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题部分
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(11:7)", "entry");
            // 标题部分
            Column.margin({ top: 80, bottom: 60 });
            // 标题部分
            Column.alignItems(HorizontalAlign.Center);
            // 标题部分
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.message);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(12:9)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('探索着');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(16:9)", "entry");
            Text.fontSize(16);
            Text.margin({ bottom: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('美丽的目的地');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(19:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        // 标题部分
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 登录表单
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(26:7)", "entry");
            // 登录表单
            Column.width('100%');
            // 登录表单
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入用户名' });
            TextInput.debugLine("entry/src/main/ets/pages/Index.ets(27:9)", "entry");
            TextInput.width('80%');
            TextInput.height(40);
            TextInput.margin({ bottom: 20 });
            TextInput.onChange((value: string) => {
                this.username = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入密码' });
            TextInput.debugLine("entry/src/main/ets/pages/Index.ets(34:9)", "entry");
            TextInput.width('80%');
            TextInput.height(40);
            TextInput.type(InputType.Password);
            TextInput.onChange((value: string) => {
                this.password = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('登录');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(41:9)", "entry");
            Button.width('80%');
            Button.height(40);
            Button.margin({ top: 30 });
            Button.onClick(() => {
                // 这里添加登录逻辑
                if (this.username && this.password) {
                    this.message = '登录中...';
                    // 实际项目中这里会有API调用
                }
                else {
                    this.message = '请输入用户名和密码';
                }
            });
        }, Button);
        Button.pop();
        // 登录表单
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 底部链接
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(58:7)", "entry");
            // 底部链接
            Column.margin({ top: 40 });
            // 底部链接
            Column.width('100%');
            // 底部链接
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('其他方式登录');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(59:9)", "entry");
            Text.fontSize(14);
            Text.margin({ bottom: 15 });
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('随便逛逛');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(63:9)", "entry");
            Text.fontSize(14);
            Text.margin({ bottom: 30 });
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('登录即表示同意《XXXX用户协议》和《隐私政策》');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(67:9)", "entry");
            Text.fontSize(12);
            Text.fontColor('#999');
        }, Text);
        Text.pop();
        // 底部链接
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "LoginPage";
    }
}
registerNamedRoute(() => new LoginPage(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
