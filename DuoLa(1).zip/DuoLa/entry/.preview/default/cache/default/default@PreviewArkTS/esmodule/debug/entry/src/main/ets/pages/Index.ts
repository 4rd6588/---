if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
}
import router from "@ohos:router";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(8:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 导航标题
            Text.create('日历提醒应用');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(10:7)", "entry");
            // 导航标题
            Text.fontSize(24);
            // 导航标题
            Text.fontWeight(FontWeight.Bold);
            // 导航标题
            Text.margin({ top: 20, bottom: 30 });
        }, Text);
        // 导航标题
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 主功能按钮
            Button.createWithLabel('查看日历', { type: ButtonType.Capsule });
            Button.debugLine("entry/src/main/ets/pages/Index.ets(16:7)", "entry");
            // 主功能按钮
            Button.width('80%');
            // 主功能按钮
            Button.height(50);
            // 主功能按钮
            Button.margin({ bottom: 20 });
            // 主功能按钮
            Button.onClick(() => {
                router.pushUrl({
                    url: 'pages/CalendarPage'
                });
            });
        }, Button);
        // 主功能按钮
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('查看所有提醒', { type: ButtonType.Capsule });
            Button.debugLine("entry/src/main/ets/pages/Index.ets(27:7)", "entry");
            Button.width('80%');
            Button.height(50);
            Button.onClick(() => {
                router.pushUrl({
                    url: 'pages/ReminderListPage'
                });
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.duola", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
