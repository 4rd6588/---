if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface CalendarPage_Params {
}
import { CalendarComponent } from "@normalized:N&&&entry/src/main/ets/pages/CalendarComponent&";
import router from "@ohos:router";
class CalendarPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CalendarPage_Params) {
    }
    updateStateVars(params: CalendarPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CalendarPage.ets(8:5)", "entry");
            Column.width('100%');
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 返回按钮
            Button.createWithLabel('返回', { type: ButtonType.Normal });
            Button.debugLine("entry/src/main/ets/pages/CalendarPage.ets(10:7)", "entry");
            // 返回按钮
            Button.width(80);
            // 返回按钮
            Button.height(40);
            // 返回按钮
            Button.alignSelf(ItemAlign.Start);
            // 返回按钮
            Button.margin(10);
            // 返回按钮
            Button.onClick(() => {
                router.back();
            });
        }, Button);
        // 返回按钮
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.layoutWeight(1);
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    // 日历组件
                    CalendarComponent(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/CalendarPage.ets", line: 20, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "CalendarComponent" });
        }
        __Common__.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "CalendarPage";
    }
}
registerNamedRoute(() => new CalendarPage(undefined, {}), "", { bundleName: "com.example.duola", moduleName: "entry", pagePath: "pages/CalendarPage", pageFullPath: "entry/src/main/ets/pages/CalendarPage", integratedHsp: "false", moduleType: "followWithHap" });
