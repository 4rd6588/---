if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ReminderEditPage_Params {
    reminder?: Reminder;
    isEditMode?: boolean;
    time?: string;
    showDateDialog?: boolean;
    showTimeDialog?: boolean;
    tempDate?: string;
    tempTime?: string;
    timeOptions?: string[];
}
import { Reminder } from "@normalized:N&&&entry/src/main/ets/pages/ReminderModel&";
import { ReminderService } from "@normalized:N&&&entry/src/main/ets/pages/ReminderService&";
import { NotificationService } from "@normalized:N&&&entry/src/main/ets/pages/NotificationService&";
import router from "@ohos:router";
import type common from "@ohos:app.ability.common";
interface RouterParams {
    id?: number;
    date?: string;
    mode?: string;
}
class ReminderEditPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__reminder = new ObservedPropertyObjectPU(new Reminder(0, '', '', '', '08:00'), this, "reminder");
        this.__isEditMode = new ObservedPropertySimplePU(false, this, "isEditMode");
        this.__time = new ObservedPropertySimplePU('08:00', this, "time");
        this.__showDateDialog = new ObservedPropertySimplePU(false, this, "showDateDialog");
        this.__showTimeDialog = new ObservedPropertySimplePU(false, this, "showTimeDialog");
        this.__tempDate = new ObservedPropertySimplePU('', this, "tempDate");
        this.__tempTime = new ObservedPropertySimplePU('08:00', this, "tempTime");
        this.timeOptions = (() => {
            const options: string[] = [];
            for (let hour = 0; hour < 24; hour++) {
                for (let minute of ['00', '30']) {
                    options.push(`${hour.toString().padStart(2, '0')}:${minute}`);
                }
            }
            return options;
        })();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ReminderEditPage_Params) {
        if (params.reminder !== undefined) {
            this.reminder = params.reminder;
        }
        if (params.isEditMode !== undefined) {
            this.isEditMode = params.isEditMode;
        }
        if (params.time !== undefined) {
            this.time = params.time;
        }
        if (params.showDateDialog !== undefined) {
            this.showDateDialog = params.showDateDialog;
        }
        if (params.showTimeDialog !== undefined) {
            this.showTimeDialog = params.showTimeDialog;
        }
        if (params.tempDate !== undefined) {
            this.tempDate = params.tempDate;
        }
        if (params.tempTime !== undefined) {
            this.tempTime = params.tempTime;
        }
        if (params.timeOptions !== undefined) {
            this.timeOptions = params.timeOptions;
        }
    }
    updateStateVars(params: ReminderEditPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__reminder.purgeDependencyOnElmtId(rmElmtId);
        this.__isEditMode.purgeDependencyOnElmtId(rmElmtId);
        this.__time.purgeDependencyOnElmtId(rmElmtId);
        this.__showDateDialog.purgeDependencyOnElmtId(rmElmtId);
        this.__showTimeDialog.purgeDependencyOnElmtId(rmElmtId);
        this.__tempDate.purgeDependencyOnElmtId(rmElmtId);
        this.__tempTime.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__reminder.aboutToBeDeleted();
        this.__isEditMode.aboutToBeDeleted();
        this.__time.aboutToBeDeleted();
        this.__showDateDialog.aboutToBeDeleted();
        this.__showTimeDialog.aboutToBeDeleted();
        this.__tempDate.aboutToBeDeleted();
        this.__tempTime.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __reminder: ObservedPropertyObjectPU<Reminder>;
    get reminder() {
        return this.__reminder.get();
    }
    set reminder(newValue: Reminder) {
        this.__reminder.set(newValue);
    }
    private __isEditMode: ObservedPropertySimplePU<boolean>;
    get isEditMode() {
        return this.__isEditMode.get();
    }
    set isEditMode(newValue: boolean) {
        this.__isEditMode.set(newValue);
    }
    private __time: ObservedPropertySimplePU<string>;
    get time() {
        return this.__time.get();
    }
    set time(newValue: string) {
        this.__time.set(newValue);
    }
    private __showDateDialog: ObservedPropertySimplePU<boolean>;
    get showDateDialog() {
        return this.__showDateDialog.get();
    }
    set showDateDialog(newValue: boolean) {
        this.__showDateDialog.set(newValue);
    }
    private __showTimeDialog: ObservedPropertySimplePU<boolean>;
    get showTimeDialog() {
        return this.__showTimeDialog.get();
    }
    set showTimeDialog(newValue: boolean) {
        this.__showTimeDialog.set(newValue);
    }
    private __tempDate: ObservedPropertySimplePU<string>;
    get tempDate() {
        return this.__tempDate.get();
    }
    set tempDate(newValue: string) {
        this.__tempDate.set(newValue);
    }
    private __tempTime: ObservedPropertySimplePU<string>;
    get tempTime() {
        return this.__tempTime.get();
    }
    set tempTime(newValue: string) {
        this.__tempTime.set(newValue);
    }
    // 可选时间列表（每半小时一个选项）
    private timeOptions: string[];
    // 日期选择方法
    private showDatePicker() {
        this.tempDate = this.reminder.date;
        this.showDateDialog = true;
    }
    // 时间选择方法
    private showTimePicker() {
        this.tempTime = this.time;
        this.showTimeDialog = true;
    }
    // 确认日期选择
    private confirmDate() {
        this.reminder.date = this.tempDate;
        this.showDateDialog = false;
    }
    // 确认时间选择
    private confirmTime() {
        this.time = this.tempTime;
        this.showTimeDialog = false;
    }
    private cancelTime() {
        this.showTimeDialog = false;
    }
    aboutToAppear() {
        const params = router.getParams() as RouterParams;
        if (params.mode === 'edit' && params?.id) {
            const existingReminder = ReminderService.getById(params.id);
            if (existingReminder) {
                this.reminder = existingReminder;
                this.isEditMode = true;
                this.time = this.reminder.time;
            }
        }
        else if (params?.date) {
            this.reminder.date = params.date;
        }
        else {
            const today = new Date();
            const year = today.getFullYear();
            const month = (today.getMonth() + 1).toString().padStart(2, '0');
            const day = today.getDate().toString().padStart(2, '0');
            this.reminder.date = `${year}-${month}-${day}`;
        }
    }
    saveReminder() {
        this.reminder.time = this.time;
        if (this.isEditMode) {
            ReminderService.update(this.reminder);
        }
        else {
            this.reminder.id = ReminderService.getNextId();
            ReminderService.add(this.reminder);
        }
        NotificationService.scheduleReminder(getContext(this) as common.UIAbilityContext, this.reminder);
        router.back();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(100:5)", "entry");
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(101:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.isEditMode ? '编辑提醒' : '新建提醒');
            Text.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(102:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.width('100%');
            Text.textAlign(TextAlign.Center);
            Text.margin({ top: 10, bottom: 20 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题
            Text.create('标题');
            Text.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(110:9)", "entry");
            // 标题
            Text.fontSize(16);
            // 标题
            Text.margin({ bottom: 5 });
        }, Text);
        // 标题
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '输入提醒标题', text: this.reminder.title });
            TextInput.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(114:9)", "entry");
            TextInput.width('100%');
            TextInput.height(40);
            TextInput.type(InputType.Normal);
            TextInput.borderRadius(5);
            TextInput.borderWidth(1);
            TextInput.borderColor(Color.Gray);
            TextInput.onChange((value: string) => {
                this.reminder.title = value;
            });
            TextInput.margin({ bottom: 15 });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 日期
            Text.create('日期');
            Text.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(127:9)", "entry");
            // 日期
            Text.fontSize(16);
            // 日期
            Text.margin({ bottom: 5 });
        }, Text);
        // 日期
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '选择日期', text: this.reminder.date });
            TextInput.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(131:9)", "entry");
            TextInput.width('100%');
            TextInput.height(40);
            TextInput.type(InputType.Normal);
            TextInput.borderRadius(5);
            TextInput.borderWidth(1);
            TextInput.borderColor(Color.Gray);
            TextInput.onClick(() => {
                this.showDatePicker();
            });
            TextInput.margin({ bottom: 15 });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 时间
            Text.create('时间');
            Text.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(144:9)", "entry");
            // 时间
            Text.fontSize(16);
            // 时间
            Text.margin({ bottom: 5 });
        }, Text);
        // 时间
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '选择时间', text: this.time });
            TextInput.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(148:9)", "entry");
            TextInput.width('100%');
            TextInput.height(40);
            TextInput.type(InputType.Normal);
            TextInput.borderRadius(5);
            TextInput.borderWidth(1);
            TextInput.borderColor(Color.Gray);
            TextInput.onClick(() => {
                this.showTimePicker();
            });
            TextInput.margin({ bottom: 15 });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 内容
            Text.create('内容');
            Text.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(161:9)", "entry");
            // 内容
            Text.fontSize(16);
            // 内容
            Text.margin({ bottom: 5 });
        }, Text);
        // 内容
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '输入提醒内容', text: this.reminder.content });
            TextInput.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(165:9)", "entry");
            TextInput.width('100%');
            TextInput.height(100);
            TextInput.type(InputType.Normal);
            TextInput.borderRadius(5);
            TextInput.borderWidth(1);
            TextInput.borderColor(Color.Gray);
            TextInput.onChange((value: string) => {
                this.reminder.content = value;
            });
            TextInput.margin({ bottom: 20 });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 保存按钮
            Button.createWithLabel(this.isEditMode ? '更新提醒' : '创建提醒', { type: ButtonType.Capsule });
            Button.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(178:9)", "entry");
            // 保存按钮
            Button.width('100%');
            // 保存按钮
            Button.height(50);
            // 保存按钮
            Button.onClick(() => this.saveReminder());
            // 保存按钮
            Button.margin({ bottom: 10 });
        }, Button);
        // 保存按钮
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isEditMode) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('删除提醒', { type: ButtonType.Capsule });
                        Button.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(185:11)", "entry");
                        Button.width('100%');
                        Button.height(50);
                        Button.backgroundColor(Color.Red);
                        Button.onClick(() => {
                            ReminderService.delete(this.reminder.id);
                            NotificationService.cancelReminder(this.reminder.id);
                            router.back();
                        });
                    }, Button);
                    Button.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 日期选择对话框
            if (this.showDateDialog) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(201:9)", "entry");
                        Column.width('80%');
                        Column.padding(20);
                        Column.backgroundColor(Color.White);
                        Column.borderRadius(10);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('选择日期');
                        Text.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(202:11)", "entry");
                        Text.fontSize(18);
                        Text.margin({ bottom: 15 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 这里可以添加更复杂的日期选择器UI
                        // 简单实现：直接输入日期
                        TextInput.create({ placeholder: 'YYYY-MM-DD', text: this.tempDate });
                        TextInput.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(208:11)", "entry");
                        // 这里可以添加更复杂的日期选择器UI
                        // 简单实现：直接输入日期
                        TextInput.width('80%');
                        // 这里可以添加更复杂的日期选择器UI
                        // 简单实现：直接输入日期
                        TextInput.onChange((value: string) => {
                            this.tempDate = value;
                        });
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(214:11)", "entry");
                        Row.width('100%');
                        Row.justifyContent(FlexAlign.SpaceAround);
                        Row.margin({ top: 20 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('取消');
                        Button.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(215:13)", "entry");
                        Button.width('40%');
                        Button.onClick(() => {
                            this.showDateDialog = false;
                        });
                    }, Button);
                    Button.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('确定');
                        Button.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(221:13)", "entry");
                        Button.width('40%');
                        Button.onClick(() => {
                            this.confirmDate();
                        });
                    }, Button);
                    Button.pop();
                    Row.pop();
                    Column.pop();
                });
            }
            // 时间选择对话框
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 时间选择对话框
            if (this.showTimeDialog) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(239:9)", "entry");
                        Column.width('80%');
                        Column.padding(20);
                        Column.backgroundColor(Color.White);
                        Column.borderRadius(10);
                        Column.shadow({ radius: 10, color: '#888888', offsetX: 0, offsetY: 0 });
                        Column.position({ x: '5%', y: '20%' });
                        Column.zIndex(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('选择时间');
                        Text.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(240:11)", "entry");
                        Text.fontSize(18);
                        Text.fontWeight(FontWeight.Bold);
                        Text.margin({ bottom: 15 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 5 });
                        List.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(245:11)", "entry");
                        List.height(300);
                        List.width('80%');
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const option = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    itemCreation2(elmtId, isInitialRender);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.borderRadius(5);
                                    ListItem.borderWidth(1);
                                    ListItem.borderColor('#eeeeee');
                                    ListItem.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(247:15)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(option);
                                        Text.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(248:17)", "entry");
                                        Text.fontSize(16);
                                        Text.width('100%');
                                        Text.textAlign(TextAlign.Center);
                                        Text.padding(10);
                                        Text.backgroundColor(this.tempTime === option ? '#f0f0f0' : Color.White);
                                        Text.onClick(() => {
                                            this.tempTime = option;
                                        });
                                    }, Text);
                                    Text.pop();
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.timeOptions, forEachItemGenFunction);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(267:11)", "entry");
                        Row.width('100%');
                        Row.justifyContent(FlexAlign.SpaceAround);
                        Row.margin({ top: 15 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('取消', { type: ButtonType.Normal });
                        Button.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(268:13)", "entry");
                        Button.width(120);
                        Button.height(40);
                        Button.onClick(() => {
                            this.showTimeDialog = false;
                        });
                    }, Button);
                    Button.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('确定', { type: ButtonType.Capsule });
                        Button.debugLine("entry/src/main/ets/pages/ReminderEditPage.ets(275:13)", "entry");
                        Button.width(120);
                        Button.height(40);
                        Button.onClick(() => {
                            this.confirmTime();
                        });
                    }, Button);
                    Button.pop();
                    Row.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ReminderEditPage";
    }
}
registerNamedRoute(() => new ReminderEditPage(undefined, {}), "", { bundleName: "com.example.duola", moduleName: "entry", pagePath: "pages/ReminderEditPage", pageFullPath: "entry/src/main/ets/pages/ReminderEditPage", integratedHsp: "false", moduleType: "followWithHap" });
