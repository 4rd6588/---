if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FitnessIndex_Params {
    fitnessRecords?: FitnessRecord[];
    isRefreshing?: boolean;
}
import type { FitnessRecord } from './FitnessRecord';
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
export class FitnessIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__fitnessRecords = new ObservedPropertyObjectPU([], this, "fitnessRecords");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FitnessIndex_Params) {
        if (params.fitnessRecords !== undefined) {
            this.fitnessRecords = params.fitnessRecords;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
    }
    updateStateVars(params: FitnessIndex_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__fitnessRecords.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__fitnessRecords.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __fitnessRecords: ObservedPropertyObjectPU<FitnessRecord[]>;
    get fitnessRecords() {
        return this.__fitnessRecords.get();
    }
    set fitnessRecords(newValue: FitnessRecord[]) {
        this.__fitnessRecords.set(newValue);
    }
    private __isRefreshing: ObservedPropertySimplePU<boolean>;
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue: boolean) {
        this.__isRefreshing.set(newValue);
    }
    aboutToAppear() {
        this.loadFitnessRecords();
    }
    loadFitnessRecords() {
        // 模拟从数据库加载数据
        this.fitnessRecords = [
            {
                id: '1',
                date: '2023-05-01',
                calories: 350,
                duration: 45,
                standTime: 8
            },
            {
                id: '2',
                date: '2023-05-02',
                calories: 420,
                duration: 60,
                standTime: 7
            }
        ];
        this.isRefreshing = false;
    }
    async deleteRecord(id: string) {
        try {
            const result = await promptAction.showDialog({
                title: { "id": 16777235, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" },
                message: { "id": 16777234, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" },
                buttons: [
                    { text: { "id": 16777233, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" }, color: '#999999' },
                    { text: { "id": 16777235, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" }, color: '#FF0000' }
                ]
            });
            if (result.index === 1) {
                this.fitnessRecords = this.fitnessRecords.filter(record => record.id !== id);
            }
        }
        catch (err) {
            console.error('删除操作失败:', err);
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(56:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(57:7)", "entry");
            Row.width('100%');
            Row.padding(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777240, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(58:9)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(62:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777231, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(64:9)", "entry");
            Button.type(ButtonType.Circle);
            Button.onClick(() => {
                router.push({ url: 'pages/health/fitness/FitnessAddEdit', params: { mode: 'add' } });
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 10, initialIndex: 0 });
            List.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(73:7)", "entry");
            List.width('100%');
            List.height('80%');
            List.divider({ strokeWidth: 1, color: '#F1F1F1' });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(75:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create();
                            Column.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(76:13)", "entry");
                            Column.width('100%');
                            Column.padding(10);
                            Column.borderRadius(10);
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(77:15)", "entry");
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.date);
                            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(78:17)", "entry");
                            Text.fontSize(18);
                            Text.fontWeight(FontWeight.Bold);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Blank.create();
                            Blank.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(82:17)", "entry");
                        }, Blank);
                        Blank.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(`${item.calories}千卡`);
                            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(84:17)", "entry");
                            Text.fontSize(16);
                        }, Text);
                        Text.pop();
                        Row.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(88:15)", "entry");
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create({ "id": 16777239, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" } + `: ${item.duration}分钟`);
                            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(89:17)", "entry");
                            Text.fontSize(14);
                            Text.fontColor('#666666');
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Blank.create();
                            Blank.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(93:17)", "entry");
                        }, Blank);
                        Blank.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create({ "id": 16777241, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" } + `: ${item.standTime}小时`);
                            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(95:17)", "entry");
                            Text.fontSize(14);
                            Text.fontColor('#666666');
                        }, Text);
                        Text.pop();
                        Row.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(100:15)", "entry");
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Blank.create();
                            Blank.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(101:17)", "entry");
                        }, Blank);
                        Blank.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(103:17)", "entry");
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel({ "id": 16777236, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
                            Button.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(104:19)", "entry");
                            Button.type(ButtonType.Normal);
                            Button.height(30);
                            Button.fontSize(12);
                            Button.onClick(() => {
                                router.push({
                                    url: 'pages/health/fitness/FitnessAddEdit',
                                    params: {
                                        mode: 'edit',
                                        record: JSON.stringify(item)
                                    }
                                });
                            });
                        }, Button);
                        Button.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel({ "id": 16777235, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
                            Button.debugLine("entry/src/main/ets/pages/health/fitness/FitnessIndex.ets(118:19)", "entry");
                            Button.type(ButtonType.Normal);
                            Button.height(30);
                            Button.fontSize(12);
                            Button.margin({ left: 10 });
                            Button.backgroundColor('#FF0000');
                            Button.onClick(() => this.deleteRecord(item.id));
                        }, Button);
                        Button.pop();
                        Row.pop();
                        Row.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.fitnessRecords, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "FitnessIndex";
    }
}
registerNamedRoute(() => new FitnessIndex(undefined, {}), "", { bundleName: "com.example.duola", moduleName: "entry", pagePath: "pages/health/fitness/FitnessIndex", pageFullPath: "entry/src/main/ets/pages/health/fitness/FitnessIndex", integratedHsp: "false", moduleType: "followWithHap" });
