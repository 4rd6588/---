if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MoodAddEdit_Params {
    mode?: 'add' | 'edit';
    record?: MoodRecord;
    datePickerVisible?: boolean;
    statusOptions?: SelectOption[];
}
import type { MoodRecord } from './MoodRecord';
import router from "@ohos:router";
interface GeneratedTypeLiteralInterface_3 {
    year: number;
    month: number;
    day: number;
}
interface GeneratedTypeLiteralInterface_2 {
    mode?: 'add' | 'edit';
    record?: string;
}
interface SelectOption {
    value: string;
    icon?: Resource | string;
}
export class MoodAddEdit extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.mode = 'add';
        this.__record = new ObservedPropertyObjectPU({
            id: '',
            date: '',
            status: '平静',
            notes: '',
            aiAdvice: ''
        }, this, "record");
        this.__datePickerVisible = new ObservedPropertySimplePU(false, this, "datePickerVisible");
        this.__statusOptions = new ObservedPropertyObjectPU([
            { value: '快乐' },
            { value: '平静' },
            { value: '焦虑' },
            { value: '悲伤' },
            { value: '愤怒' },
            { value: '疲惫' },
            { value: '兴奋' }
        ], this, "statusOptions");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MoodAddEdit_Params) {
        if (params.mode !== undefined) {
            this.mode = params.mode;
        }
        if (params.record !== undefined) {
            this.record = params.record;
        }
        if (params.datePickerVisible !== undefined) {
            this.datePickerVisible = params.datePickerVisible;
        }
        if (params.statusOptions !== undefined) {
            this.statusOptions = params.statusOptions;
        }
    }
    updateStateVars(params: MoodAddEdit_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__record.purgeDependencyOnElmtId(rmElmtId);
        this.__datePickerVisible.purgeDependencyOnElmtId(rmElmtId);
        this.__statusOptions.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__record.aboutToBeDeleted();
        this.__datePickerVisible.aboutToBeDeleted();
        this.__statusOptions.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private mode: 'add' | 'edit';
    private __record: ObservedPropertyObjectPU<MoodRecord>;
    get record() {
        return this.__record.get();
    }
    set record(newValue: MoodRecord) {
        this.__record.set(newValue);
    }
    private __datePickerVisible: ObservedPropertySimplePU<boolean>;
    get datePickerVisible() {
        return this.__datePickerVisible.get();
    }
    set datePickerVisible(newValue: boolean) {
        this.__datePickerVisible.set(newValue);
    }
    private __statusOptions: ObservedPropertyObjectPU<SelectOption[]>;
    get statusOptions() {
        return this.__statusOptions.get();
    }
    set statusOptions(newValue: SelectOption[]) {
        this.__statusOptions.set(newValue);
    }
    aboutToAppear() {
        const params = router.getParams() as GeneratedTypeLiteralInterface_2;
        if (params?.mode) {
            this.mode = params.mode;
            if (this.mode === 'edit' && params.record) {
                try {
                    this.record = JSON.parse(params.record) as MoodRecord;
                }
                catch (e) {
                    console.error('Failed to parse record:', e);
                }
            }
            else {
                // 设置默认日期为当前日期
                const now = new Date();
                this.record.date = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')}`;
            }
        }
    }
    saveRecord() {
        // 这里应该是保存到数据库的逻辑
        console.log('保存记录:', this.record);
        router.back();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(68:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.mode === 'add' ? { "id": 16777231, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" } : { "id": 16777236, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(69:7)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ bottom: 20 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 日期选择部分
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(75:7)", "entry");
            // 日期选择部分
            Row.width('100%');
            // 日期选择部分
            Row.margin({ bottom: 15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777244, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(76:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.record.date);
            Button.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(79:9)", "entry");
            Button.type(ButtonType.Normal);
            Button.margin({ left: 10 });
            Button.onClick(() => {
                this.datePickerVisible = true;
            });
        }, Button);
        Button.pop();
        // 日期选择部分
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.datePickerVisible) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        DatePicker.create({
                            start: new Date('1970-01-01'),
                            end: new Date('2100-12-31'),
                            selected: new Date(this.record.date)
                        });
                        DatePicker.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(90:9)", "entry");
                        DatePicker.onChange((value: GeneratedTypeLiteralInterface_3) => {
                            this.record.date = `${value.year}-${value.month.toString().padStart(2, '0')}-${value.day.toString().padStart(2, '0')}`;
                            this.datePickerVisible = false;
                        });
                    }, DatePicker);
                    DatePicker.pop();
                });
            }
            // 心理状态选择
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 心理状态选择
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(102:7)", "entry");
            // 心理状态选择
            Row.width('100%');
            // 心理状态选择
            Row.margin({ bottom: 15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777247, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(103:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Select.create(this.statusOptions);
            Select.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(106:9)", "entry");
            Select.value(this.record.status);
            Select.onSelect((index: number) => {
                this.record.status = this.statusOptions[index].value;
            });
            Select.margin({ left: 10 });
        }, Select);
        Select.pop();
        // 心理状态选择
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 备注输入
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(117:7)", "entry");
            // 备注输入
            Column.width('100%');
            // 备注输入
            Column.margin({ bottom: 30 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777245, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(118:9)", "entry");
            Text.fontSize(16);
            Text.margin({ bottom: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextArea.create({ text: this.record.notes, placeholder: '请输入你的心理状态描述...' });
            TextArea.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(122:9)", "entry");
            TextArea.width('100%');
            TextArea.height(100);
            TextArea.onChange((value: string) => {
                this.record.notes = value;
            });
        }, TextArea);
        // 备注输入
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777248, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/pages/health/mood/MoodAddEdit.ets(132:7)", "entry");
            Button.width('80%');
            Button.height(50);
            Button.fontSize(18);
            Button.onClick(() => this.saveRecord());
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "MoodAddEdit";
    }
}
registerNamedRoute(() => new MoodAddEdit(undefined, {}), "", { bundleName: "com.example.duola", moduleName: "entry", pagePath: "pages/health/mood/MoodAddEdit", pageFullPath: "entry/src/main/ets/pages/health/mood/MoodAddEdit", integratedHsp: "false", moduleType: "followWithHap" });
