import { Reminder } from "@normalized:N&&&entry/src/main/ets/pages/ReminderModel&";
import storage from "@ohos:data.storage";
const STORAGE_KEY = 'reminders';
let reminders: Reminder[] = [];
let storageInstance: storage.Storage;
// 定义存储项的接口
interface StoredReminder {
    id: number;
    title: string;
    content: string;
    date: string;
    time: string;
}
export class ReminderService {
    private static async saveAll(): Promise<void> {
        if (!storageInstance) {
            await ReminderService.init();
        }
        await storageInstance.put(STORAGE_KEY, JSON.stringify(reminders));
        await storageInstance.flush();
    }
    static async init(): Promise<void> {
        try {
            storageInstance = await storage.getStorage('/data/reminders.db');
            const data = await storageInstance.get(STORAGE_KEY, '[]');
            let jsonString: string;
            if (typeof data === 'string') {
                jsonString = data;
            }
            else if (typeof data === 'number') {
                jsonString = data.toString();
            }
            else {
                jsonString = '[]'; // 默认值
            }
            const parsedData: StoredReminder[] = JSON.parse(jsonString);
            reminders = parsedData.map(item => new Reminder(item.id, item.title, item.content, item.date, item.time));
        }
        catch (error) {
            console.error('Failed to initialize reminders:', error);
            reminders = [];
        }
    }
    static getAll(): Reminder[] {
        return [...reminders];
    }
    static getByDate(date: string): Reminder[] {
        return reminders.filter(r => r.date === date).sort((a, b) => a.time.localeCompare(b.time));
    }
    static getById(id: number): Reminder | undefined {
        return reminders.find(r => r.id === id);
    }
    static async add(reminder: Reminder): Promise<void> {
        reminders.push(reminder);
        await ReminderService.saveAll();
    }
    static async update(reminder: Reminder): Promise<boolean> {
        const index = reminders.findIndex(r => r.id === reminder.id);
        if (index >= 0) {
            reminders[index] = reminder;
            await ReminderService.saveAll();
            return true;
        }
        return false;
    }
    static async delete(id: number): Promise<boolean> {
        const index = reminders.findIndex(r => r.id === id);
        if (index >= 0) {
            reminders.splice(index, 1);
            await ReminderService.saveAll();
            return true;
        }
        return false;
    }
    static getNextId(): number {
        return reminders.length > 0 ? Math.max(...reminders.map(r => r.id)) + 1 : 1;
    }
}
