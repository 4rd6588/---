if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ReminderListPage_Params {
    reminders?: Reminder[];
}
import type { Reminder } from '../pages/ReminderModel';
import { ReminderService } from "@normalized:N&&&entry/src/main/ets/pages/ReminderService&";
import router from "@ohos:router";
class ReminderListPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__reminders = new ObservedPropertyObjectPU(ReminderService.getAll(), this, "reminders");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ReminderListPage_Params) {
        if (params.reminders !== undefined) {
            this.reminders = params.reminders;
        }
    }
    updateStateVars(params: ReminderListPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__reminders.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__reminders.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __reminders: ObservedPropertyObjectPU<Reminder[]>;
    get reminders() {
        return this.__reminders.get();
    }
    set reminders(newValue: Reminder[]) {
        this.__reminders.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ReminderListPage.ets(11:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题和返回按钮
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ReminderListPage.ets(13:7)", "entry");
            // 标题和返回按钮
            Row.width('100%');
            // 标题和返回按钮
            Row.padding(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('返回', { type: ButtonType.Normal });
            Button.debugLine("entry/src/main/ets/pages/ReminderListPage.ets(14:9)", "entry");
            Button.width(80);
            Button.height(40);
            Button.onClick(() => {
                router.back();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('所有提醒事项');
            Text.debugLine("entry/src/main/ets/pages/ReminderListPage.ets(21:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.layoutWeight(1);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        // 标题和返回按钮
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 提醒列表
            List.create({ space: 10 });
            List.debugLine("entry/src/main/ets/pages/ReminderListPage.ets(31:7)", "entry");
            // 提醒列表
            List.layoutWeight(1);
            // 提醒列表
            List.width('100%');
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const reminder = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/ReminderListPage.ets(33:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create();
                            Column.debugLine("entry/src/main/ets/pages/ReminderListPage.ets(34:13)", "entry");
                            Column.width('100%');
                            Column.padding(10);
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(reminder.title);
                            Text.debugLine("entry/src/main/ets/pages/ReminderListPage.ets(35:15)", "entry");
                            Text.fontSize(18);
                            Text.fontWeight(FontWeight.Bold);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(`${reminder.date} ${reminder.time}`);
                            Text.debugLine("entry/src/main/ets/pages/ReminderListPage.ets(40:15)", "entry");
                            Text.fontSize(14);
                            Text.fontColor(Color.Gray);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel('查看详情', { type: ButtonType.Normal });
                            Button.debugLine("entry/src/main/ets/pages/ReminderListPage.ets(45:15)", "entry");
                            Button.width(120);
                            Button.margin({ top: 5 });
                            Button.onClick(() => {
                                router.pushUrl({
                                    url: 'pages/ReminderEditPage',
                                    params: {
                                        mode: 'edit',
                                        id: reminder.id
                                    }
                                });
                            });
                        }, Button);
                        Button.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.reminders, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        // 提醒列表
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ReminderListPage";
    }
}
registerNamedRoute(() => new ReminderListPage(undefined, {}), "", { bundleName: "com.example.duola", moduleName: "entry", pagePath: "pages/ReminderListPage", pageFullPath: "entry/src/main/ets/pages/ReminderListPage", integratedHsp: "false", moduleType: "followWithHap" });
