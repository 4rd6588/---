if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface HealthIndex_Params {
}
import router from "@ohos:router";
export class HealthIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: HealthIndex_Params) {
    }
    updateStateVars(params: HealthIndex_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/health/HealthIndex.ets(7:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777242, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/HealthIndex.ets(8:7)", "entry");
            Text.fontSize(25);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 20, bottom: 40 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777251, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/pages/health/HealthIndex.ets(13:7)", "entry");
            Button.width('80%');
            Button.height(60);
            Button.fontSize(18);
            Button.margin({ bottom: 20 });
            Button.onClick(() => {
                router.push({ url: 'pages/health/sleep/SleepIndex' });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777240, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/pages/health/HealthIndex.ets(22:7)", "entry");
            Button.width('80%');
            Button.height(60);
            Button.fontSize(18);
            Button.margin({ bottom: 20 });
            Button.onClick(() => {
                router.push({ url: 'pages/health/fitness/FitnessIndex' });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777246, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/pages/health/HealthIndex.ets(31:7)", "entry");
            Button.width('80%');
            Button.height(60);
            Button.fontSize(18);
            Button.margin({ bottom: 20 });
            Button.onClick(() => {
                router.push({ url: 'pages/health/mood/MoodIndex' });
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "HealthIndex";
    }
}
registerNamedRoute(() => new HealthIndex(undefined, {}), "", { bundleName: "com.example.duola", moduleName: "entry", pagePath: "pages/health/HealthIndex", pageFullPath: "entry/src/main/ets/pages/health/HealthIndex", integratedHsp: "false", moduleType: "followWithHap" });
