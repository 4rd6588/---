if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FitnessAddEdit_Params {
    mode?: 'add' | 'edit';
    record?: FitnessRecord;
    datePickerVisible?: boolean;
}
import type { FitnessRecord } from './FitnessRecord';
import router from "@ohos:router";
interface GeneratedTypeLiteralInterface_1 {
    mode?: 'add' | 'edit';
    record?: string;
}
interface GeneratedTypeLiteralInterface_2 {
    year: number;
    month: number;
    day: number;
}
export class FitnessAddEdit extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.mode = 'add';
        this.__record = new ObservedPropertyObjectPU({
            id: '',
            date: '',
            calories: 0,
            duration: 0,
            standTime: 0
        }, this, "record");
        this.__datePickerVisible = new ObservedPropertySimplePU(false, this, "datePickerVisible");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FitnessAddEdit_Params) {
        if (params.mode !== undefined) {
            this.mode = params.mode;
        }
        if (params.record !== undefined) {
            this.record = params.record;
        }
        if (params.datePickerVisible !== undefined) {
            this.datePickerVisible = params.datePickerVisible;
        }
    }
    updateStateVars(params: FitnessAddEdit_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__record.purgeDependencyOnElmtId(rmElmtId);
        this.__datePickerVisible.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__record.aboutToBeDeleted();
        this.__datePickerVisible.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private mode: 'add' | 'edit';
    private __record: ObservedPropertyObjectPU<FitnessRecord>;
    get record() {
        return this.__record.get();
    }
    set record(newValue: FitnessRecord) {
        this.__record.set(newValue);
    }
    private __datePickerVisible: ObservedPropertySimplePU<boolean>;
    get datePickerVisible() {
        return this.__datePickerVisible.get();
    }
    set datePickerVisible(newValue: boolean) {
        this.__datePickerVisible.set(newValue);
    }
    aboutToAppear() {
        const params = router.getParams() as GeneratedTypeLiteralInterface_1;
        if (params?.mode) {
            this.mode = params.mode;
            if (this.mode === 'edit' && params.record) {
                try {
                    this.record = JSON.parse(params.record) as FitnessRecord;
                }
                catch (e) {
                    console.error('Failed to parse record:', e);
                }
            }
            else {
                // 设置默认日期为当前日期
                const now = new Date();
                this.record.date = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')}`;
            }
        }
    }
    saveRecord() {
        // 这里应该是保存到数据库的逻辑
        console.log('保存记录:', this.record);
        router.back();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(54:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.mode === 'add' ? { "id": 16777231, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" } : { "id": 16777236, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(55:7)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ bottom: 20 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 日期选择部分
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(61:7)", "entry");
            // 日期选择部分
            Row.width('100%');
            // 日期选择部分
            Row.margin({ bottom: 15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777238, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(62:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.record.date);
            Button.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(65:9)", "entry");
            Button.type(ButtonType.Normal);
            Button.margin({ left: 10 });
            Button.onClick(() => {
                this.datePickerVisible = true;
            });
        }, Button);
        Button.pop();
        // 日期选择部分
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.datePickerVisible) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        DatePicker.create({
                            start: new Date('1970-01-01'),
                            end: new Date('2100-12-31'),
                            selected: new Date(this.record.date)
                        });
                        DatePicker.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(76:9)", "entry");
                        DatePicker.onChange((value: GeneratedTypeLiteralInterface_2) => {
                            this.record.date = `${value.year}-${value.month.toString().padStart(2, '0')}-${value.day.toString().padStart(2, '0')}`;
                            this.datePickerVisible = false;
                        });
                    }, DatePicker);
                    DatePicker.pop();
                });
            }
            // 卡路里输入
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 卡路里输入
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(88:7)", "entry");
            // 卡路里输入
            Row.width('100%');
            // 卡路里输入
            Row.margin({ bottom: 15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777237, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(89:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ text: this.record.calories.toString(), placeholder: '请输入消耗卡路里' });
            TextInput.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(92:9)", "entry");
            TextInput.type(InputType.Number);
            TextInput.width('50%');
            TextInput.height(40);
            TextInput.margin({ left: 10 });
            TextInput.onChange((value: string) => {
                this.record.calories = parseFloat(value) || 0;
            });
        }, TextInput);
        // 卡路里输入
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 锻炼时间输入
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(105:7)", "entry");
            // 锻炼时间输入
            Row.width('100%');
            // 锻炼时间输入
            Row.margin({ bottom: 15 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777239, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(106:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ text: this.record.duration.toString(), placeholder: '请输入锻炼时间(分钟)' });
            TextInput.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(109:9)", "entry");
            TextInput.type(InputType.Number);
            TextInput.width('50%');
            TextInput.height(40);
            TextInput.margin({ left: 10 });
            TextInput.onChange((value: string) => {
                this.record.duration = parseFloat(value) || 0;
            });
        }, TextInput);
        // 锻炼时间输入
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 站立时间输入
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(122:7)", "entry");
            // 站立时间输入
            Row.width('100%');
            // 站立时间输入
            Row.margin({ bottom: 30 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777241, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(123:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ text: this.record.standTime.toString(), placeholder: '请输入站立时间(小时)' });
            TextInput.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(126:9)", "entry");
            TextInput.type(InputType.Number);
            TextInput.width('50%');
            TextInput.height(40);
            TextInput.margin({ left: 10 });
            TextInput.onChange((value: string) => {
                this.record.standTime = parseFloat(value) || 0;
            });
        }, TextInput);
        // 站立时间输入
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777248, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/pages/health/fitness/FitnessAddEdit.ets(138:7)", "entry");
            Button.width('80%');
            Button.height(50);
            Button.fontSize(18);
            Button.onClick(() => this.saveRecord());
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "FitnessAddEdit";
    }
}
registerNamedRoute(() => new FitnessAddEdit(undefined, {}), "", { bundleName: "com.example.duola", moduleName: "entry", pagePath: "pages/health/fitness/FitnessAddEdit", pageFullPath: "entry/src/main/ets/pages/health/fitness/FitnessAddEdit", integratedHsp: "false", moduleType: "followWithHap" });
