if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ReminderItem_Params {
    reminder?: Reminder;
    onEdit?: () => void;
    onDelete?: () => void;
}
interface CalendarComponent_Params {
    currentYear?: number;
    currentMonth?: number;
    selectedDate?: string;
    reminders?: Reminder[];
    calendarDays?: CalendarDay[][];
}
import type { Reminder } from './ReminderModel';
import { ReminderService } from "@normalized:N&&&entry/src/main/ets/pages/ReminderService&";
import router from "@ohos:router";
interface CalendarDay {
    day: number;
    isCurrentMonth: boolean;
}
class CalendarComponent extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentYear = new ObservedPropertySimplePU(new Date().getFullYear(), this, "currentYear");
        this.__currentMonth = new ObservedPropertySimplePU(new Date().getMonth() + 1, this, "currentMonth");
        this.__selectedDate = new ObservedPropertySimplePU(this.formatDate(new Date()), this, "selectedDate");
        this.__reminders = new ObservedPropertyObjectPU([], this, "reminders");
        this.__calendarDays = new ObservedPropertyObjectPU([], this, "calendarDays");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CalendarComponent_Params) {
        if (params.currentYear !== undefined) {
            this.currentYear = params.currentYear;
        }
        if (params.currentMonth !== undefined) {
            this.currentMonth = params.currentMonth;
        }
        if (params.selectedDate !== undefined) {
            this.selectedDate = params.selectedDate;
        }
        if (params.reminders !== undefined) {
            this.reminders = params.reminders;
        }
        if (params.calendarDays !== undefined) {
            this.calendarDays = params.calendarDays;
        }
    }
    updateStateVars(params: CalendarComponent_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentYear.purgeDependencyOnElmtId(rmElmtId);
        this.__currentMonth.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDate.purgeDependencyOnElmtId(rmElmtId);
        this.__reminders.purgeDependencyOnElmtId(rmElmtId);
        this.__calendarDays.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentYear.aboutToBeDeleted();
        this.__currentMonth.aboutToBeDeleted();
        this.__selectedDate.aboutToBeDeleted();
        this.__reminders.aboutToBeDeleted();
        this.__calendarDays.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentYear: ObservedPropertySimplePU<number>;
    get currentYear() {
        return this.__currentYear.get();
    }
    set currentYear(newValue: number) {
        this.__currentYear.set(newValue);
    }
    private __currentMonth: ObservedPropertySimplePU<number>;
    get currentMonth() {
        return this.__currentMonth.get();
    }
    set currentMonth(newValue: number) {
        this.__currentMonth.set(newValue);
    }
    private __selectedDate: ObservedPropertySimplePU<string>;
    get selectedDate() {
        return this.__selectedDate.get();
    }
    set selectedDate(newValue: string) {
        this.__selectedDate.set(newValue);
    }
    private __reminders: ObservedPropertyObjectPU<Reminder[]>;
    get reminders() {
        return this.__reminders.get();
    }
    set reminders(newValue: Reminder[]) {
        this.__reminders.set(newValue);
    }
    // 日历数据
    private __calendarDays: ObservedPropertyObjectPU<CalendarDay[][]>;
    get calendarDays() {
        return this.__calendarDays.get();
    }
    set calendarDays(newValue: CalendarDay[][]) {
        this.__calendarDays.set(newValue);
    }
    aboutToAppear() {
        this.generateCalendar();
        this.loadReminders();
    }
    formatDate(date: Date): string {
        const year = date.getFullYear();
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const day = date.getDate().toString().padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    loadReminders() {
        this.reminders = ReminderService.getByDate(this.selectedDate);
    }
    generateCalendar() {
        const firstDay = new Date(this.currentYear, this.currentMonth - 1, 1);
        const lastDay = new Date(this.currentYear, this.currentMonth, 0);
        const startDay = firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1; // 调整周一为一周的第一天
        const totalDays = lastDay.getDate();
        const prevMonthLastDay = new Date(this.currentYear, this.currentMonth - 1, 0).getDate();
        let calendar: CalendarDay[][] = [];
        let week: CalendarDay[] = [];
        // 上个月的日期
        for (let i = startDay - 1; i >= 0; i--) {
            week.push({ day: prevMonthLastDay - i, isCurrentMonth: false });
            if (week.length === 7) {
                calendar.push([...week]);
                week = [];
            }
        }
        // 当前月的日期
        for (let i = 1; i <= totalDays; i++) {
            week.push({ day: i, isCurrentMonth: true });
            if (week.length === 7) {
                calendar.push([...week]);
                week = [];
            }
        }
        // 下个月的日期
        let nextMonthDay = 1;
        while (week.length > 0 && week.length < 7) {
            week.push({ day: nextMonthDay, isCurrentMonth: false });
            nextMonthDay++;
            if (week.length === 7) {
                calendar.push([...week]);
                week = [];
            }
        }
        this.calendarDays = calendar;
    }
    changeMonth(offset: number) {
        let newMonth = this.currentMonth + offset;
        let newYear = this.currentYear;
        if (newMonth < 1) {
            newMonth = 12;
            newYear--;
        }
        else if (newMonth > 12) {
            newMonth = 1;
            newYear++;
        }
        this.currentMonth = newMonth;
        this.currentYear = newYear;
        this.generateCalendar();
    }
    selectDay(day: number, isCurrentMonth: boolean) {
        if (!isCurrentMonth) {
            this.changeMonth(day > 15 ? -1 : 1);
            return;
        }
        const formattedMonth = this.currentMonth.toString().padStart(2, '0');
        const formattedDay = day.toString().padStart(2, '0');
        this.selectedDate = `${this.currentYear}-${formattedMonth}-${formattedDay}`;
        this.loadReminders();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(112:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(15);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 月份导航
            Row.create({ space: 20 });
            Row.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(114:7)", "entry");
            // 月份导航
            Row.justifyContent(FlexAlign.Center);
            // 月份导航
            Row.width('100%');
            // 月份导航
            Row.margin({ top: 10, bottom: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('<', { type: ButtonType.Normal, stateEffect: true });
            Button.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(115:9)", "entry");
            Button.onClick(() => this.changeMonth(-1));
            Button.width(40);
            Button.height(40);
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.currentYear}年${this.currentMonth}月`);
            Text.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(120:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('>', { type: ButtonType.Normal, stateEffect: true });
            Button.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(124:9)", "entry");
            Button.onClick(() => this.changeMonth(1));
            Button.width(40);
            Button.height(40);
        }, Button);
        Button.pop();
        // 月份导航
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 星期标题
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(134:7)", "entry");
            // 星期标题
            Row.width('100%');
            // 星期标题
            Row.margin({ bottom: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const day = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(day);
                    Text.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(136:11)", "entry");
                    Text.fontSize(16);
                    Text.fontWeight(FontWeight.Bold);
                    Text.textAlign(TextAlign.Center);
                    Text.width('14.28%');
                }, Text);
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, ['一', '二', '三', '四', '五', '六', '日'], forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        // 星期标题
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 日历日期
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const week = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(148:9)", "entry");
                    Row.width('100%');
                    Row.margin({ bottom: 5 });
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const dayInfo = _item;
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create();
                            Column.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(150:13)", "entry");
                            Column.width('14.28%');
                            Column.height(40);
                            Column.borderRadius(20);
                            Column.backgroundColor(dayInfo.isCurrentMonth &&
                                this.selectedDate === `${this.currentYear}-${this.currentMonth.toString().padStart(2, '0')}-${dayInfo.day.toString().padStart(2, '0')}` ?
                                Color.Blue : Color.Transparent);
                            Column.onClick(() => this.selectDay(dayInfo.day, dayInfo.isCurrentMonth));
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            // 将变量声明和使用都放在Column组件内部
                            Text.create(dayInfo.day.toString());
                            Text.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(152:15)", "entry");
                            // 将变量声明和使用都放在Column组件内部
                            Text.fontSize(16);
                            // 将变量声明和使用都放在Column组件内部
                            Text.fontColor(dayInfo.isCurrentMonth ?
                                (this.selectedDate === `${this.currentYear}-${this.currentMonth.toString().padStart(2, '0')}-${dayInfo.day.toString().padStart(2, '0')}` ?
                                    Color.White : Color.Black) :
                                Color.Gray);
                            // 将变量声明和使用都放在Column组件内部
                            Text.textAlign(TextAlign.Center);
                            // 将变量声明和使用都放在Column组件内部
                            Text.width('100%');
                        }, Text);
                        // 将变量声明和使用都放在Column组件内部
                        Text.pop();
                        Column.pop();
                    };
                    this.forEachUpdateFunction(elmtId, week, forEachItemGenFunction);
                }, ForEach);
                ForEach.pop();
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.calendarDays, forEachItemGenFunction);
        }, ForEach);
        // 日历日期
        ForEach.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 提醒列表标题
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(177:7)", "entry");
            // 提醒列表标题
            Row.width('100%');
            // 提醒列表标题
            Row.margin({ top: 20, bottom: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('提醒事项');
            Text.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(178:9)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(182:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('+', { type: ButtonType.Normal, stateEffect: true });
            Button.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(184:9)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: 'pages/ReminderEditPage',
                    params: { date: this.selectedDate }
                });
            });
            Button.width(25);
            Button.height(25);
        }, Button);
        Button.pop();
        // 提醒列表标题
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 提醒列表
            if (this.reminders.length > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create({ space: 10 });
                        List.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(199:9)", "entry");
                        List.layoutWeight(1);
                        List.width('100%');
                        List.height('30%');
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const reminder = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    itemCreation2(elmtId, isInitialRender);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(201:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(202:15)", "entry");
                                        Column.width('100%');
                                        Column.padding(10);
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(reminder.title);
                                        Text.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(203:17)", "entry");
                                        Text.fontSize(18);
                                        Text.fontWeight(FontWeight.Bold);
                                        Text.textAlign(TextAlign.Start);
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(`${reminder.date} ${reminder.time}`);
                                        Text.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(208:17)", "entry");
                                        Text.fontSize(14);
                                        Text.fontColor(Color.Gray);
                                        Text.textAlign(TextAlign.Start);
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Button.createWithLabel('查看详情', { type: ButtonType.Normal });
                                        Button.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(213:17)", "entry");
                                        Button.width(120);
                                        Button.margin({ top: 5 });
                                        Button.onClick(() => {
                                            router.pushUrl({
                                                url: 'pages/ReminderEditPage',
                                                params: {
                                                    mode: 'edit',
                                                    id: reminder.id
                                                }
                                            });
                                        });
                                    }, Button);
                                    Button.pop();
                                    Column.pop();
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.reminders, forEachItemGenFunction);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('当天没有提醒事项');
                        Text.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(235:9)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Color.Gray);
                        Text.textAlign(TextAlign.Center);
                        Text.width('100%');
                        Text.margin({ top: 20 });
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "CalendarComponent";
    }
}
class ReminderItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__reminder = new SynchedPropertyObjectOneWayPU(params.reminder, this, "reminder");
        this.__onEdit = new SynchedPropertyObjectOneWayPU(params.onEdit, this, "onEdit");
        this.__onDelete = new SynchedPropertyObjectOneWayPU(params.onDelete, this, "onDelete");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ReminderItem_Params) {
    }
    updateStateVars(params: ReminderItem_Params) {
        this.__reminder.reset(params.reminder);
        this.__onEdit.reset(params.onEdit);
        this.__onDelete.reset(params.onDelete);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__reminder.purgeDependencyOnElmtId(rmElmtId);
        this.__onEdit.purgeDependencyOnElmtId(rmElmtId);
        this.__onDelete.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__reminder.aboutToBeDeleted();
        this.__onEdit.aboutToBeDeleted();
        this.__onDelete.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __reminder: SynchedPropertySimpleOneWayPU<Reminder>;
    get reminder() {
        return this.__reminder.get();
    }
    set reminder(newValue: Reminder) {
        this.__reminder.set(newValue);
    }
    private __onEdit: SynchedPropertySimpleOneWayPU<() => void>;
    get onEdit() {
        return this.__onEdit.get();
    }
    set onEdit(newValue: () => void) {
        this.__onEdit.set(newValue);
    }
    private __onDelete: SynchedPropertySimpleOneWayPU<() => void>;
    get onDelete() {
        return this.__onDelete.get();
    }
    set onDelete(newValue: () => void) {
        this.__onDelete.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(256:5)", "entry");
            Row.width('100%');
            Row.padding(10);
            Row.backgroundColor(Color.White);
            Row.borderRadius(5);
            Row.shadow({ radius: 2, color: Color.Gray, offsetX: 1, offsetY: 1 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(257:7)", "entry");
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.reminder.title);
            Text.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(258:9)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.reminder.date} ${this.reminder.time}`);
            Text.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(262:9)", "entry");
            Text.fontSize(14);
            Text.fontColor(Color.Gray);
            Text.margin({ top: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.reminder.content);
            Text.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(267:9)", "entry");
            Text.fontSize(14);
            Text.margin({ top: 5 });
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(273:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('编辑', { type: ButtonType.Normal });
            Button.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(274:9)", "entry");
            Button.onClick(() => this.onEdit());
            Button.width(60);
            Button.height(30);
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('删除', { type: ButtonType.Normal });
            Button.debugLine("entry/src/main/ets/pages/CalendarComponent.ets(279:9)", "entry");
            Button.onClick(() => this.onDelete());
            Button.width(60);
            Button.height(30);
        }, Button);
        Button.pop();
        Row.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export { CalendarComponent };
registerNamedRoute(() => new CalendarComponent(undefined, {}), "", { bundleName: "com.example.duola", moduleName: "entry", pagePath: "pages/CalendarComponent", pageFullPath: "entry/src/main/ets/pages/CalendarComponent", integratedHsp: "false", moduleType: "followWithHap" });
