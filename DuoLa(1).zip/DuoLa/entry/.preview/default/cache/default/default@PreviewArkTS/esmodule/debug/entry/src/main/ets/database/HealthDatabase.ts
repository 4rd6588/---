import relationalStore from "@ohos:data.relationalStore";
import type { SleepRecord } from '../pages/health/sleep/SleepRecord';
import type { FitnessRecord } from '../pages/health/fitness/FitnessRecord';
import type { MoodRecord } from '../pages/health/mood/MoodRecord';
import type common from "@ohos:app.ability.common";
export class HealthDatabase {
    private static instance: HealthDatabase;
    private rdbStore: relationalStore.RdbStore | null = null;
    private constructor() { }
    public static getInstance(): HealthDatabase {
        if (!HealthDatabase.instance) {
            HealthDatabase.instance = new HealthDatabase();
        }
        return HealthDatabase.instance;
    }
    async initialize(context: common.Context) {
        const STORE_CONFIG: relationalStore.StoreConfig = {
            name: 'HealthNotepad.db',
            securityLevel: relationalStore.SecurityLevel.S1
        };
        const SQL_CREATE_SLEEP_TABLE = `
      CREATE TABLE IF NOT EXISTS sleep_records (
        id TEXT PRIMARY KEY,
        date TEXT NOT NULL,
        sleepHours REAL NOT NULL,
        quality TEXT NOT NULL
      )`;
        const SQL_CREATE_FITNESS_TABLE = `
      CREATE TABLE IF NOT EXISTS fitness_records (
        id TEXT PRIMARY KEY,
        date TEXT NOT NULL,
        calories REAL NOT NULL,
        duration INTEGER NOT NULL,
        standTime REAL NOT NULL
      )`;
        const SQL_CREATE_MOOD_TABLE = `
      CREATE TABLE IF NOT EXISTS mood_records (
        id TEXT PRIMARY KEY,
        date TEXT NOT NULL,
        status TEXT NOT NULL,
        notes TEXT,
        aiAdvice TEXT
      )`;
        try {
            this.rdbStore = await relationalStore.getRdbStore(context, STORE_CONFIG);
            await this.rdbStore.executeSql(SQL_CREATE_SLEEP_TABLE);
            await this.rdbStore.executeSql(SQL_CREATE_FITNESS_TABLE);
            await this.rdbStore.executeSql(SQL_CREATE_MOOD_TABLE);
        }
        catch (err) {
            console.error(`Failed to initialize database: ${JSON.stringify(err)}`);
        }
    }
    // ============= 睡眠记录操作 =============
    async addSleepRecord(record: SleepRecord): Promise<boolean> {
        if (!this.rdbStore)
            return false;
        const valueBucket: relationalStore.ValuesBucket = {
            'id': record.id,
            'date': record.date,
            'sleepHours': record.sleepHours,
            'quality': record.quality
        };
        try {
            await this.rdbStore.insert('sleep_records', valueBucket);
            return true;
        }
        catch (err) {
            console.error(`Failed to add sleep record: ${JSON.stringify(err)}`);
            return false;
        }
    }
    async updateSleepRecord(record: SleepRecord): Promise<boolean> {
        if (!this.rdbStore)
            return false;
        const valueBucket: relationalStore.ValuesBucket = {
            'date': record.date,
            'sleepHours': record.sleepHours,
            'quality': record.quality
        };
        try {
            const predicates = new relationalStore.RdbPredicates('sleep_records');
            predicates.equalTo('id', record.id);
            await this.rdbStore.update(valueBucket, predicates);
            return true;
        }
        catch (err) {
            console.error(`Failed to update sleep record: ${JSON.stringify(err)}`);
            return false;
        }
    }
    async deleteSleepRecord(id: string): Promise<boolean> {
        if (!this.rdbStore)
            return false;
        try {
            const predicates = new relationalStore.RdbPredicates('sleep_records');
            predicates.equalTo('id', id);
            await this.rdbStore.delete(predicates);
            return true;
        }
        catch (err) {
            console.error(`Failed to delete sleep record: ${JSON.stringify(err)}`);
            return false;
        }
    }
    async getAllSleepRecords(): Promise<SleepRecord[]> {
        if (!this.rdbStore)
            return [];
        try {
            const predicates = new relationalStore.RdbPredicates('sleep_records');
            const columns = ['id', 'date', 'sleepHours', 'quality'];
            const resultSet = await this.rdbStore.query(predicates, columns);
            const records: SleepRecord[] = [];
            while (resultSet.goToNextRow()) {
                records.push({
                    id: resultSet.getString(resultSet.getColumnIndex('id')),
                    date: resultSet.getString(resultSet.getColumnIndex('date')),
                    sleepHours: resultSet.getDouble(resultSet.getColumnIndex('sleepHours')),
                    quality: resultSet.getString(resultSet.getColumnIndex('quality')) as '优秀' | '良好' | '一般'
                });
            }
            resultSet.close();
            return records;
        }
        catch (err) {
            console.error(`Failed to get sleep records: ${JSON.stringify(err)}`);
            return [];
        }
    }
    // ============= 健身记录操作 =============
    async addFitnessRecord(record: FitnessRecord): Promise<boolean> {
        if (!this.rdbStore)
            return false;
        const valueBucket: relationalStore.ValuesBucket = {
            'id': record.id,
            'date': record.date,
            'calories': record.calories,
            'duration': record.duration,
            'standTime': record.standTime
        };
        try {
            await this.rdbStore.insert('fitness_records', valueBucket);
            return true;
        }
        catch (err) {
            console.error(`Failed to add fitness record: ${JSON.stringify(err)}`);
            return false;
        }
    }
    async updateFitnessRecord(record: FitnessRecord): Promise<boolean> {
        if (!this.rdbStore)
            return false;
        const valueBucket: relationalStore.ValuesBucket = {
            'date': record.date,
            'calories': record.calories,
            'duration': record.duration,
            'standTime': record.standTime
        };
        try {
            const predicates = new relationalStore.RdbPredicates('fitness_records');
            predicates.equalTo('id', record.id);
            await this.rdbStore.update(valueBucket, predicates);
            return true;
        }
        catch (err) {
            console.error(`Failed to update fitness record: ${JSON.stringify(err)}`);
            return false;
        }
    }
    async deleteFitnessRecord(id: string): Promise<boolean> {
        if (!this.rdbStore)
            return false;
        try {
            const predicates = new relationalStore.RdbPredicates('fitness_records');
            predicates.equalTo('id', id);
            await this.rdbStore.delete(predicates);
            return true;
        }
        catch (err) {
            console.error(`Failed to delete fitness record: ${JSON.stringify(err)}`);
            return false;
        }
    }
    async getAllFitnessRecords(): Promise<FitnessRecord[]> {
        if (!this.rdbStore)
            return [];
        try {
            const predicates = new relationalStore.RdbPredicates('fitness_records');
            const columns = ['id', 'date', 'calories', 'duration', 'standTime'];
            const resultSet = await this.rdbStore.query(predicates, columns);
            const records: FitnessRecord[] = [];
            while (resultSet.goToNextRow()) {
                records.push({
                    id: resultSet.getString(resultSet.getColumnIndex('id')),
                    date: resultSet.getString(resultSet.getColumnIndex('date')),
                    calories: resultSet.getDouble(resultSet.getColumnIndex('calories')),
                    duration: resultSet.getDouble(resultSet.getColumnIndex('duration')),
                    standTime: resultSet.getDouble(resultSet.getColumnIndex('standTime'))
                });
            }
            resultSet.close();
            return records;
        }
        catch (err) {
            console.error(`Failed to get fitness records: ${JSON.stringify(err)}`);
            return [];
        }
    }
    // ============= 心理状态操作 =============
    async addMoodRecord(record: MoodRecord): Promise<boolean> {
        if (!this.rdbStore)
            return false;
        const valueBucket: relationalStore.ValuesBucket = {
            'id': record.id,
            'date': record.date,
            'status': record.status,
            'notes': record.notes,
            'aiAdvice': record.aiAdvice || ''
        };
        try {
            await this.rdbStore.insert('mood_records', valueBucket);
            return true;
        }
        catch (err) {
            console.error(`Failed to add mood record: ${JSON.stringify(err)}`);
            return false;
        }
    }
    async updateMoodRecord(record: MoodRecord): Promise<boolean> {
        if (!this.rdbStore)
            return false;
        const valueBucket: relationalStore.ValuesBucket = {
            'date': record.date,
            'status': record.status,
            'notes': record.notes,
            'aiAdvice': record.aiAdvice || ''
        };
        try {
            const predicates = new relationalStore.RdbPredicates('mood_records');
            predicates.equalTo('id', record.id);
            await this.rdbStore.update(valueBucket, predicates);
            return true;
        }
        catch (err) {
            console.error(`Failed to update mood record: ${JSON.stringify(err)}`);
            return false;
        }
    }
    async deleteMoodRecord(id: string): Promise<boolean> {
        if (!this.rdbStore)
            return false;
        try {
            const predicates = new relationalStore.RdbPredicates('mood_records');
            predicates.equalTo('id', id);
            await this.rdbStore.delete(predicates);
            return true;
        }
        catch (err) {
            console.error(`Failed to delete mood record: ${JSON.stringify(err)}`);
            return false;
        }
    }
    async getAllMoodRecords(): Promise<MoodRecord[]> {
        if (!this.rdbStore)
            return [];
        try {
            const predicates = new relationalStore.RdbPredicates('mood_records');
            const columns = ['id', 'date', 'status', 'notes', 'aiAdvice'];
            const resultSet = await this.rdbStore.query(predicates, columns);
            const records: MoodRecord[] = [];
            while (resultSet.goToNextRow()) {
                records.push({
                    id: resultSet.getString(resultSet.getColumnIndex('id')),
                    date: resultSet.getString(resultSet.getColumnIndex('date')),
                    status: resultSet.getString(resultSet.getColumnIndex('status')),
                    notes: resultSet.getString(resultSet.getColumnIndex('notes')),
                    aiAdvice: resultSet.getString(resultSet.getColumnIndex('aiAdvice'))
                });
            }
            resultSet.close();
            return records;
        }
        catch (err) {
            console.error(`Failed to get mood records: ${JSON.stringify(err)}`);
            return [];
        }
    }
}
