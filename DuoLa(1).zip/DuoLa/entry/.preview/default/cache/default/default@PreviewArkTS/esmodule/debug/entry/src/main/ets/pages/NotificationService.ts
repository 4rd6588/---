import type { Reminder } from './ReminderModel';
import reminderAgent from "@ohos:reminderAgent";
import type common from "@ohos:app.ability.common";
// 1. 首先定义所有需要的接口
interface ActionButton {
    title: string;
    type: reminderAgent.ActionButtonType;
}
interface WantAgent {
    pkgName: string;
    abilityName: string;
}
interface ReminderRequest {
    reminderType: reminderAgent.ReminderType;
    triggerTimeInSeconds: number;
    actionButton: [
        ActionButton
    ];
    wantAgent: WantAgent;
    title: string;
    content: string;
    expiredContent: string;
    snoozeContent: string;
    notificationId: number;
}
export class NotificationService {
    static async scheduleReminder(context: common.UIAbilityContext, reminder: Reminder) {
        try {
            // 2. 使用明确定义的接口类型
            const reminderRequest: ReminderRequest = {
                reminderType: reminderAgent.ReminderType.REMINDER_TYPE_TIMER,
                triggerTimeInSeconds: Math.floor(reminder.timestamp / 1000),
                actionButton: [{
                        title: '查看',
                        type: reminderAgent.ActionButtonType.ACTION_BUTTON_TYPE_CLOSE
                    }],
                wantAgent: {
                    pkgName: context.abilityInfo.bundleName,
                    abilityName: context.abilityInfo.name
                },
                title: reminder.title,
                content: reminder.content,
                expiredContent: '提醒已过期',
                snoozeContent: '稍后提醒',
                notificationId: reminder.id
            };
            await reminderAgent.publishReminder(reminderRequest);
        }
        catch (error) {
            console.error(`Failed to schedule reminder: ${JSON.stringify(error)}`);
        }
    }
    static async cancelReminder(reminderId: number) {
        try {
            await reminderAgent.cancelReminder(reminderId);
        }
        catch (error) {
            console.error(`Failed to cancel reminder: ${JSON.stringify(error)}`);
        }
    }
}
