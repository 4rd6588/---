if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MoodIndex_Params {
    moodRecords?: MoodRecord[];
    isRefreshing?: boolean;
}
import type { MoodRecord } from './MoodRecord';
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
export class MoodIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__moodRecords = new ObservedPropertyObjectPU([], this, "moodRecords");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MoodIndex_Params) {
        if (params.moodRecords !== undefined) {
            this.moodRecords = params.moodRecords;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
    }
    updateStateVars(params: MoodIndex_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__moodRecords.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__moodRecords.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __moodRecords: ObservedPropertyObjectPU<MoodRecord[]>;
    get moodRecords() {
        return this.__moodRecords.get();
    }
    set moodRecords(newValue: MoodRecord[]) {
        this.__moodRecords.set(newValue);
    }
    private __isRefreshing: ObservedPropertySimplePU<boolean>;
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue: boolean) {
        this.__isRefreshing.set(newValue);
    }
    aboutToAppear() {
        this.loadMoodRecords();
    }
    loadMoodRecords() {
        // 模拟从数据库加载数据
        this.moodRecords = [
            {
                id: '1',
                date: '2023-05-01',
                status: '快乐',
                notes: '今天和朋友出去玩得很开心',
                aiAdvice: '继续保持积极社交活动，这对心理健康很有帮助。'
            },
            {
                id: '2',
                date: '2023-05-02',
                status: '焦虑',
                notes: '工作压力大，感到有些焦虑',
                aiAdvice: '建议尝试深呼吸练习或短暂冥想，每天10分钟可以有效缓解焦虑。'
            }
        ];
        this.isRefreshing = false;
    }
    async deleteRecord(id: string) {
        try {
            const result = await promptAction.showDialog({
                title: { "id": 16777235, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" },
                message: { "id": 16777234, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" },
                buttons: [
                    { text: { "id": 16777233, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" }, color: '#999999' },
                    { text: { "id": 16777235, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" }, color: '#FF0000' }
                ]
            });
            if (result.index === 1) {
                this.moodRecords = this.moodRecords.filter(record => record.id !== id);
            }
        }
        catch (err) {
            console.error('删除操作失败:', err);
        }
    }
    async getAiAdvice(record: MoodRecord): Promise<string> {
        // 模拟AI建议生成
        return new Promise((resolve) => {
            setTimeout(() => {
                const adviceMap: Record<string, string> = {
                    '快乐': '继续保持这种积极情绪，分享你的快乐可以让他人也感到快乐。',
                    '焦虑': '尝试深呼吸或冥想，每天10-15分钟可以帮助缓解焦虑。',
                    '悲伤': '允许自己感受悲伤，与信任的人谈谈你的感受会有帮助。',
                    '愤怒': '尝试数到10或离开当前环境，等冷静下来再处理问题。',
                    '平静': '平静是很好的状态，可以尝试冥想或瑜伽来维持这种状态。'
                };
                resolve(adviceMap[record.status] || '保持自我觉察，记录情绪变化有助于理解自己的心理状态。');
            }, 500);
        });
    }
    async updateAiAdvice(record: MoodRecord) {
        try {
            const advice = await this.getAiAdvice(record);
            const index = this.moodRecords.findIndex(r => r.id === record.id);
            if (index !== -1) {
                this.moodRecords[index].aiAdvice = advice;
                this.moodRecords = [...this.moodRecords];
            }
        }
        catch (err) {
            console.error('获取AI建议失败:', err);
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(85:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(86:7)", "entry");
            Row.width('100%');
            Row.padding(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777246, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(87:9)", "entry");
            Text.fontSize(22);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(91:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 16777231, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
            Button.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(93:9)", "entry");
            Button.type(ButtonType.Circle);
            Button.onClick(() => {
                router.push({ url: 'pages/health/mood/MoodAddEdit', params: { mode: 'add' } });
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 10, initialIndex: 0 });
            List.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(102:7)", "entry");
            List.width('100%');
            List.height('80%');
            List.divider({ strokeWidth: 1, color: '#F1F1F1' });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.borderRadius(10);
                        ListItem.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(104:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create();
                            Column.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(105:13)", "entry");
                            Column.width('100%');
                            Column.padding(10);
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(106:15)", "entry");
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.date);
                            Text.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(107:17)", "entry");
                            Text.fontSize(18);
                            Text.fontWeight(FontWeight.Bold);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Blank.create();
                            Blank.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(111:17)", "entry");
                        }, Blank);
                        Blank.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.status);
                            Text.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(113:17)", "entry");
                            Text.fontSize(16);
                        }, Text);
                        Text.pop();
                        Row.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            If.create();
                            if (item.notes) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.notes);
                                        Text.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(118:17)", "entry");
                                        Text.fontSize(14);
                                        Text.fontColor('#666666');
                                        Text.margin({ top: 5, bottom: 5 });
                                        Text.width('100%');
                                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                        Text.maxLines(2);
                                    }, Text);
                                    Text.pop();
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                });
                            }
                        }, If);
                        If.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            If.create();
                            if (item.aiAdvice) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(128:17)", "entry");
                                        Column.width('100%');
                                        Column.padding(8);
                                        Column.backgroundColor('#F5F5F5');
                                        Column.borderRadius(8);
                                        Column.margin({ top: 5, bottom: 5 });
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create({ "id": 16777232, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
                                        Text.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(129:19)", "entry");
                                        Text.fontSize(14);
                                        Text.fontColor('#333333');
                                        Text.fontWeight(FontWeight.Bold);
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.aiAdvice);
                                        Text.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(134:19)", "entry");
                                        Text.fontSize(13);
                                        Text.fontColor('#666666');
                                        Text.margin({ top: 3 });
                                    }, Text);
                                    Text.pop();
                                    Column.pop();
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                });
                            }
                        }, If);
                        If.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(146:15)", "entry");
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel('更新AI建议');
                            Button.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(147:17)", "entry");
                            Button.type(ButtonType.Normal);
                            Button.height(30);
                            Button.fontSize(12);
                            Button.onClick(() => this.updateAiAdvice(item));
                        }, Button);
                        Button.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Blank.create();
                            Blank.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(153:17)", "entry");
                        }, Blank);
                        Blank.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(155:17)", "entry");
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel({ "id": 16777236, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
                            Button.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(156:19)", "entry");
                            Button.type(ButtonType.Normal);
                            Button.height(30);
                            Button.fontSize(12);
                            Button.onClick(() => {
                                router.push({
                                    url: 'pages/health/mood/MoodAddEdit',
                                    params: {
                                        mode: 'edit',
                                        record: JSON.stringify(item)
                                    }
                                });
                            });
                        }, Button);
                        Button.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel({ "id": 16777235, "type": 10003, params: [], "bundleName": "com.example.duola", "moduleName": "entry" });
                            Button.debugLine("entry/src/main/ets/pages/health/mood/MoodIndex.ets(170:19)", "entry");
                            Button.type(ButtonType.Normal);
                            Button.height(30);
                            Button.fontSize(12);
                            Button.margin({ left: 10 });
                            Button.backgroundColor('#FF0000');
                            Button.onClick(() => this.deleteRecord(item.id));
                        }, Button);
                        Button.pop();
                        Row.pop();
                        Row.pop();
                        Column.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.moodRecords, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "MoodIndex";
    }
}
registerNamedRoute(() => new MoodIndex(undefined, {}), "", { bundleName: "com.example.duola", moduleName: "entry", pagePath: "pages/health/mood/MoodIndex", pageFullPath: "entry/src/main/ets/pages/health/mood/MoodIndex", integratedHsp: "false", moduleType: "followWithHap" });
