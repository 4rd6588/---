export class Reminder {
    id: number = 0;
    title: string = '';
    content: string = '';
    date: string = ''; // 格式: YYYY-MM-DD
    time: string = ''; // 格式: HH:mm
    timestamp: number = 0; // 用于排序和比较的时间戳
    constructor(id: number, title: string, content: string, date: string, time: string) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.date = date;
        this.time = time;
        this.timestamp = new Date(`${date}T${time}`).getTime();
    }
}
